import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useDataStore } from '../context/DataContext';
import { Button, Modal, Input, EmptyState, Table, TableHead, TableHeader, TableBody, TableRow, TableCell, DaysBadge } from '../components/UI';
import { uid, today, esc, daysLeft } from '../utils/helpers';
import { Plus, Printer, Edit, Trash2 } from 'lucide-react';

export const Flights: React.FC = () => {
  const { canEdit, canPrint } = useAuth();
  const { flights, pilgrims, clients, addFlight, updateFlight, deleteFlight } = useDataStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', date: '', seats: 45, notes: '' });
  const [errors, setErrors] = useState<string[]>([]);

  const activeFlights = flights.filter(f => !f.deleted);

  const handleOpenAdd = () => {
    setEditId(null);
    setFormData({ name: '', date: '', seats: 45, notes: '' });
    setErrors([]);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (flight: typeof activeFlights[0]) => {
    setEditId(flight.id);
    setFormData({ name: flight.name, date: flight.date, seats: flight.seats || 45, notes: flight.notes || '' });
    setErrors([]);
    setIsModalOpen(true);
  };

  const handleSave = () => {
    const errs: string[] = [];
    if (formData.name.length < 2) errs.push('اسم الرحلة يجب أن يكون حرفين على الأقل');
    if (!formData.date) errs.push('يرجى إدخال تاريخ الرحلة');

    if (errs.length) {
      setErrors(errs);
      return;
    }

    const userEmail = useDataStore.getState().currentUser;

    if (editId) {
      updateFlight(editId, formData, userEmail);
    } else {
      addFlight({
        id: uid(),
        name: formData.name,
        date: formData.date,
        seats: Number(formData.seats),
        notes: formData.notes,
        createdAt: today(),
        deleted: false,
      }, userEmail);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (confirm(`نقل "${name}" إلى الأرشيف؟`)) {
      deleteFlight(id, useDataStore.getState().currentUser);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-3.5 flex-wrap gap-2">
        <span className="text-muted text-[13px]">{activeFlights.length} رحلة</span>
        {canEdit() && (
          <Button variant="teal" onClick={handleOpenAdd} className="flex items-center gap-1">
            <Plus size={14} /> إضافة رحلة
          </Button>
        )}
      </div>

      {activeFlights.length === 0 ? (
        <EmptyState icon="✈️" message="لا توجد رحلات بعد" />
      ) : (
        <div className="bg-navy-2 border border-white/10 rounded-xl overflow-hidden">
          <Table>
            <TableHead>
              <TableHeader>اسم الرحلة</TableHeader>
              <TableHeader>التاريخ</TableHeader>
              <TableHeader>أيام متبقية</TableHeader>
              <TableHeader>الحالة</TableHeader>
              <TableHeader>المعتمرين</TableHeader>
              <TableHeader>العملاء</TableHeader>
              <TableHeader>إجراءات</TableHeader>
            </TableHead>
            <TableBody>
              {activeFlights.map((fl, i) => {
                const pils = pilgrims.filter(p => !p.deleted && p.status !== 'ملغي' && p.flightId === fl.id).length;
                const cl = clients.filter(c => !c.deleted && c.flightId === fl.id).length;
                const days = daysLeft(fl.date);
                return (
                  <TableRow key={fl.id} even={i % 2 === 0}>
                    <TableCell><b className="text-gold">{esc(fl.name)}</b></TableCell>
                    <TableCell>{esc(fl.date)}</TableCell>
                    <TableCell><DaysBadge days={days} /></TableCell>
                    <TableCell>
                      <span className={`inline-block rounded-full px-2 py-0.5 text-[11px] font-semibold ${days > 0 ? 'bg-green-light/20 text-green' : 'bg-rose-light/20 text-rose'}`}>
                        {days > 0 ? 'قيد التسجيل' : 'منتهية'}
                      </span>
                    </TableCell>
                    <TableCell className="text-teal font-semibold">{pils}</TableCell>
                    <TableCell>{cl}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        {canPrint() && (
                          <button className="bg-purple text-white rounded-md px-1.5 py-1 text-[11px] hover:opacity-85">
                            <Printer size={12} />
                          </button>
                        )}
                        {canEdit() && (
                          <>
                            <button onClick={() => handleOpenEdit(fl)} className="bg-teal text-white rounded-md px-1.5 py-1 text-[11px] hover:opacity-85">
                              <Edit size={12} />
                            </button>
                            <button onClick={() => handleDelete(fl.id, fl.name)} className="bg-rose text-white rounded-md px-1.5 py-1 text-[11px] hover:opacity-85">
                              <Trash2 size={12} />
                            </button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editId ? '✏️ تعديل بيانات الرحلة' : '✈️ إضافة رحلة جديدة'}
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsModalOpen(false)}>إلغاء</Button>
            <Button variant="teal" onClick={handleSave}>{editId ? 'حفظ التعديل' : 'إضافة'}</Button>
          </>
        }
      >
        {errors.length > 0 && (
          <div className="bg-rose/10 border border-rose/30 rounded-lg p-2.5 mb-3 text-rose text-xs">
            {errors.map((e, i) => <div key={i}>⚠️ {e}</div>)}
          </div>
        )}
        <div className="space-y-3">
          <Input label="اسم الرحلة *" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} />
          <Input label="تاريخ الرحلة *" type="date" value={formData.date} onChange={e => setFormData({ ...formData, date: e.target.value })} />
          <Input label="عدد المقاعد" type="number" value={formData.seats} onChange={e => setFormData({ ...formData, seats: Number(e.target.value) })} />
          <Input label="ملاحظات" value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} />
        </div>
      </Modal>
    </div>
  );
};
