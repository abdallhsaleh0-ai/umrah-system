import React, { useState, useMemo } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useDataStore } from '../context/DataContext';
import { Button, Modal, Input, Select, EmptyState, Table, TableHead, TableHeader, TableBody, TableRow, TableCell, PassportBadge, StatusBadge, GenderBadge, HotelBadge } from '../components/UI';
import { uid, today, esc, getHotelsList } from '../utils/helpers';
import { validatePilgrim } from '../utils/validators';
import { GENDER_OPTIONS, STATUS_OPTIONS, VISA_OPTIONS, MILITARY_OPTIONS, ROOM_OPTIONS } from '../constants';
import { Plus, Printer, Edit, Trash2, Building, FileSpreadsheet } from 'lucide-react';

export const Pilgrims: React.FC = () => {
  const { canEdit, canPrint } = useAuth();
  const { flights, clients, pilgrims, addPilgrim, updatePilgrim, deletePilgrim } = useDataStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [flightFilter, setFlightFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [formData, setFormData] = useState({
    name: '', passport: '', birth: '', expiry: '', gender: 'ذكر', nationality: '',
    hotel: '', room_type: '', visa_type: 'عمرة', military: 'غير مطلوب',
    status: 'مكتمل' as const, address: '', mahram: '', relation: '',
    missing: '', clientCode: '', flightId: '', notes: ''
  });
  const [errors, setErrors] = useState<string[]>([]);

  const activeFlights = flights.filter(f => !f.deleted);
  const activeClients = clients.filter(c => !c.deleted);
  const activePilgrims = pilgrims.filter(p => !p.deleted && p.status !== 'ملغي');

  const filteredPilgrims = useMemo(() => {
    return activePilgrims.filter(p => {
      if (search && !p.name.includes(search) && !p.passport.includes(search)) return false;
      if (flightFilter && p.flightId !== flightFilter) return false;
      if (statusFilter && p.status !== statusFilter) return false;
      return true;
    });
  }, [activePilgrims, search, flightFilter, statusFilter]);

  const handleOpenAdd = () => {
    setEditId(null);
    setFormData({
      name: '', passport: '', birth: '', expiry: '', gender: 'ذكر', nationality: '',
      hotel: '', room_type: '', visa_type: 'عمرة', military: 'غير مطلوب',
      status: 'مكتمل', address: '', mahram: '', relation: '',
      missing: '', clientCode: '', flightId: '', notes: ''
    });
    setErrors([]);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (pilgrim: typeof activePilgrims[0]) => {
    setEditId(pilgrim.id);
    setFormData({
      name: pilgrim.name, passport: pilgrim.passport, birth: pilgrim.birth || '',
      expiry: pilgrim.expiry || '', gender: pilgrim.gender, nationality: pilgrim.nationality || '',
      hotel: pilgrim.hotel || '', room_type: pilgrim.room_type || '', visa_type: pilgrim.visa_type || 'عمرة',
      military: pilgrim.military || 'غير مطلوب', status: pilgrim.status,
      address: pilgrim.address || '', mahram: pilgrim.mahram || '', relation: pilgrim.relation || '',
      missing: pilgrim.missing || '', clientCode: pilgrim.clientCode, flightId: pilgrim.flightId,
      notes: pilgrim.notes || ''
    });
    setErrors([]);
    setIsModalOpen(true);
  };

  const handleSave = () => {
    const errs = validatePilgrim(formData.name, formData.passport, formData.birth, activePilgrims, editId);
    if (errs.length) {
      setErrors(errs);
      return;
    }

    const userEmail = useDataStore.getState().currentUser;
    const roomType = formData.room_type === 'بدون تحديد' ? undefined : formData.room_type || undefined;
    const data = { ...formData, room_type: roomType };

    if (editId) {
      updatePilgrim(editId, data, userEmail);
    } else {
      addPilgrim({ id: uid(), addedAt: today(), deleted: false, ...data }, userEmail);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (confirm(`نقل "${name}" إلى الأرشيف؟`)) {
      deletePilgrim(id, useDataStore.getState().currentUser);
    }
  };

  const hotelsList = getHotelsList(activePilgrims);

  const flightOptions = [{ value: '', label: 'كل الرحلات' }, ...activeFlights.map(f => ({ value: f.id, label: f.name }))];
  const statusOptions = [{ value: '', label: 'كل الحالات' }, ...STATUS_OPTIONS.map(s => ({ value: s, label: s }))];
  const clientOptions = [{ value: '', label: 'اختر عميل' }, ...activeClients.map(c => ({ value: c.code, label: `${c.name} (${c.code})` }))];
  const flightSelectOptions = [{ value: '', label: 'اختر رحلة' }, ...activeFlights.map(f => ({ value: f.id, label: f.name }))];

  return (
    <div>
      <div className="flex items-center gap-2 mb-3.5 flex-wrap">
        <Input className="w-[160px]" placeholder="بحث بالاسم أو الجواز" value={search} onChange={e => setSearch(e.target.value)} />
        <Select className="w-[160px]" options={flightOptions} value={flightFilter} onChange={e => setFlightFilter(e.target.value)} />
        <Select className="w-[160px]" options={statusOptions} value={statusFilter} onChange={e => setStatusFilter(e.target.value)} />
        <div className="flex-1" />
        <span className="text-muted text-[12px]">{filteredPilgrims.length} معتمر</span>
        {canPrint() && (
          <>
            <Button variant="purple" size="sm" className="flex items-center gap-1"><Printer size={12} /> طباعة</Button>
            <Button variant="teal" size="sm" className="flex items-center gap-1"><Building size={12} /> كشف الفنادق</Button>
            <Button variant="success" size="sm" className="flex items-center gap-1"><FileSpreadsheet size={12} /> Excel</Button>
          </>
        )}
        {canEdit() && (
          <Button variant="teal" onClick={handleOpenAdd} className="flex items-center gap-1"><Plus size={14} /> إضافة معتمر</Button>
        )}
      </div>

      {filteredPilgrims.length === 0 ? (
        <EmptyState icon="🗂️" message={activePilgrims.length === 0 ? "لا يوجد معتمرين بعد" : "لا توجد نتائج"} />
      ) : (
        <div className="bg-navy-2 border border-white/10 rounded-xl overflow-hidden">
          <Table className="min-w-[800px]">
            <TableHead>
              <TableHeader>الاسم</TableHeader>
              <TableHeader>رقم الجواز</TableHeader>
              <TableHeader>النوع</TableHeader>
              <TableHeader>الفندق</TableHeader>
              <TableHeader>نوع الغرفة</TableHeader>
              <TableHeader>التأشيرة</TableHeader>
              <TableHeader>حالة الجواز</TableHeader>
              <TableHeader>الحالة</TableHeader>
              <TableHeader>العميل</TableHeader>
              <TableHeader>الرحلة</TableHeader>
              <TableHeader>إجراءات</TableHeader>
            </TableHead>
            <TableBody>
              {filteredPilgrims.map((p, i) => {
                const fl = activeFlights.find(f => f.id === p.flightId);
                const cl = activeClients.find(c => c.code === p.clientCode);
                return (
                  <TableRow key={p.id} even={i % 2 === 0}>
                    <TableCell><b className="text-white">{esc(p.name)}</b></TableCell>
                    <TableCell className="text-muted text-[12px] font-mono">{esc(p.passport)}</TableCell>
                    <TableCell><GenderBadge gender={p.gender} /></TableCell>
                    <TableCell><HotelBadge hotel={p.hotel} /></TableCell>
                    <TableCell className="text-gold text-[12px]">{esc(p.room_type || '-')}</TableCell>
                    <TableCell>
                      <span className="bg-gold/15 text-gold px-2 py-0.5 rounded-full text-[11px]">{esc(p.visa_type || 'عمرة')}</span>
                    </TableCell>
                    <TableCell><PassportBadge expiry={p.expiry} /></TableCell>
                    <TableCell><StatusBadge status={p.status} /></TableCell>
                    <TableCell className="text-gold text-[12px]">{esc(cl?.name || p.clientCode || '-')}</TableCell>
                    <TableCell className="text-teal text-[12px]">{esc(fl?.name || '-')}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        {canEdit() && (
                          <>
                            <button onClick={() => handleOpenEdit(p)} className="bg-teal text-white rounded-md px-1.5 py-1 text-[11px] hover:opacity-85"><Edit size={12} /></button>
                            <button onClick={() => handleDelete(p.id, p.name)} className="bg-rose text-white rounded-md px-1.5 py-1 text-[11px] hover:opacity-85"><Trash2 size={12} /></button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editId ? '✏️ تعديل بيانات المعتمر' : '🗂️ إضافة معتمر جديد'} footer={
        <>
          <Button variant="ghost" onClick={() => setIsModalOpen(false)}>إلغاء</Button>
          <Button variant="teal" onClick={handleSave}>{editId ? 'حفظ التعديل' : 'إضافة المعتمر'}</Button>
        </>
      }>
        {errors.length > 0 && (
          <div className="bg-rose/10 border border-rose/30 rounded-lg p-2.5 mb-3 text-rose text-xs">
            {errors.map((e, i) => <div key={i}>⚠️ {e}</div>)}
          </div>
        )}
        <div className="grid grid-cols-2 gap-3">
          <Input label="الاسم الكامل *" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} />
          <Input label="رقم الجواز *" value={formData.passport} onChange={e => setFormData({ ...formData, passport: e.target.value })} />
          <Input label="تاريخ الميلاد" type="date" value={formData.birth} onChange={e => setFormData({ ...formData, birth: e.target.value })} />
          <Input label="انتهاء الجواز" type="date" value={formData.expiry} onChange={e => setFormData({ ...formData, expiry: e.target.value })} />
          <Select label="النوع" options={GENDER_OPTIONS.map(g => ({ value: g, label: g }))} value={formData.gender} onChange={e => setFormData({ ...formData, gender: e.target.value as any })} />
          <Input label="الجنسية" placeholder="مثال: مصري" value={formData.nationality} onChange={e => setFormData({ ...formData, nationality: e.target.value })} />
          <div>
            <label className="block text-muted text-xs mb-1">فندق الرحلة</label>
            <input list="hotels-list" className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-[13px] text-gray-200 outline-none focus:border-gold/50 w-full" value={formData.hotel} onChange={e => setFormData({ ...formData, hotel: e.target.value })} placeholder="اكتب أو اختر اسم الفندق" />
            <datalist id="hotels-list">{hotelsList.map(h => <option key={h} value={h} />)}</datalist>
          </div>
          <Select label="نوع الغرفة" options={[{ value: '', label: '-- اختر --' }, ...ROOM_OPTIONS.map(r => ({ value: r, label: r }))]} value={formData.room_type} onChange={e => setFormData({ ...formData, room_type: e.target.value })} />
          <Select label="نوع التأشيرة" options={VISA_OPTIONS.map(v => ({ value: v, label: v }))} value={formData.visa_type} onChange={e => setFormData({ ...formData, visa_type: e.target.value })} />
          <Select label="الحالة" options={STATUS_OPTIONS.map(s => ({ value: s, label: s }))} value={formData.status} onChange={e => setFormData({ ...formData, status: e.target.value as any })} />
          <Select label="التجنيد" options={MILITARY_OPTIONS.map(m => ({ value: m, label: m }))} value={formData.military} onChange={e => setFormData({ ...formData, military: e.target.value })} />
          <Select label="العميل" options={clientOptions} value={formData.clientCode} onChange={e => setFormData({ ...formData, clientCode: e.target.value })} />
          <Select label="الرحلة" options={flightSelectOptions} value={formData.flightId} onChange={e => setFormData({ ...formData, flightId: e.target.value })} />
          <Input label="اسم المحرم" value={formData.mahram} onChange={e => setFormData({ ...formData, mahram: e.target.value })} />
          <Input label="صلة القرابة" value={formData.relation} onChange={e => setFormData({ ...formData, relation: e.target.value })} />
          <Input label="النواقص" placeholder="مثال: صورة الميلاد" value={formData.missing} onChange={e => setFormData({ ...formData, missing: e.target.value })} />
        </div>
        <div className="mt-3 space-y-2">
          <Input label="العنوان" value={formData.address} onChange={e => setFormData({ ...formData, address: e.target.value })} />
          <Input label="ملاحظات" value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} />
        </div>
      </Modal>
    </div>
  );
};
