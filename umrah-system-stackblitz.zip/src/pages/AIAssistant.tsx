import React, { useState, useRef, useEffect } from 'react';
import { useDataStore } from '../context/DataContext';
import { Input } from '../components/UI';
import { localSmartAI, buildAIContext } from '../utils/ai';
import { ANTHROPIC_API_KEY } from '../constants';
import { Send, Printer } from 'lucide-react';
import { esc } from '../utils/helpers';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const SUGGESTIONS = [
  'كام معتمر إجمالي؟',
  'اعمل ملخص للرحلات',
  'الجوازات المنتهية',
  'الجنسيات',
  'الأرشيف',
  'مين الناقص مستنداتهم؟',
  'توزيع الفنادق',
  'عرض تقرير عن العملاء',
];

export const AIAssistant: React.FC = () => {
  const { pilgrims, flights, clients } = useDataStore();
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'مرحباً! 👋 أنا مساعدك الذكي.\nبياناتك محفوظة على Firebase السحابي وأقرأها مباشرة!\n\nاسألني أي سؤال عن رحلاتك وعملائك ومعتمريك.' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  useEffect(() => scrollToBottom(), [messages, loading]);

  const sendMessage = async (text?: string) => {
    const q = text || input.trim();
    if (!q || loading) return;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: q }]);
    setLoading(true);

    let reply: string;
    try {
      const fullContext = buildAIContext(flights, clients, pilgrims);
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-3-haiku-20240307',
          max_tokens: 1000,
          system: `أنت مساعد إداري ذكي ضمن نظام إدارة رحلات العمرة. تجيب دائماً بالعربية بدقة ووضوح. استخدم فقط الأرقام الموجودة في البيانات أدناه. إذا سُئلت عن شخص غير موجود، صرّح بذلك. ${fullContext}`,
          messages: [{ role: 'user', content: q }]
        })
      });
      if (!res.ok) throw new Error('API error');
      const data = await res.json();
      reply = data.content?.[0]?.text || localSmartAI(q, pilgrims, flights, clients);
    } catch {
      reply = localSmartAI(q, pilgrims, flights, clients);
    }

    setMessages(prev => [...prev, { role: 'assistant', content: reply }]);
    setLoading(false);
  };

  const handlePrint = () => {
    const w = window.open('', '_blank');
    const rows = messages.map(m => {
      const bg = m.role === 'user' ? '#e8f0fe' : '#f0fff0';
      const bc = m.role === 'user' ? '#4285f4' : '#34a853';
      const label = m.role === 'user' ? '👤 السؤال' : '🤖 المساعد الذكي';
      return `<div style="margin-bottom:14px;padding:10px;border-radius:8px;background:${bg};border-right:4px solid ${bc}"><b>${label}:</b><div style="margin-top:6px;white-space:pre-wrap">${esc(m.content)}</div></div>`;
    }).join('');

    w!.document.write(`<!DOCTYPE html><html dir="rtl"><head><meta charset="UTF-8"><title>تقرير المساعد الذكي</title><style>body{font-family:Arial,sans-serif;padding:20px}h1{color:#c9a84c}</style></head><body><h1>🤖 تقرير المساعد الذكي</h1><p>${new Date().toLocaleDateString('ar-EG')}</p>${rows}</body></html>`);
    w!.document.close();
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)]">
      <div className="flex-1 overflow-y-auto space-y-3 pb-3">
        {messages.map((m, i) => (
          <div key={i} className={`flex gap-2.5 items-end ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm flex-shrink-0 ${m.role === 'user' ? 'bg-white/10' : 'bg-gradient-to-br from-gold to-teal'}`}>
              {m.role === 'user' ? '👤' : '🤖'}
            </div>
            <div className={`max-w-[76%] px-3.5 py-2.5 text-[13px] leading-relaxed whitespace-pre-wrap border border-white/10 ${m.role === 'user' ? 'bg-gradient-to-br from-teal to-teal-700 rounded-2xl rounded-tr-sm text-white' : 'bg-white/[0.07] rounded-2xl rounded-tl-sm text-gray-200'}`}>
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-2.5 items-end">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-sm flex-shrink-0 bg-gradient-to-br from-gold to-teal">🤖</div>
            <div className="bg-white/[0.07] rounded-2xl rounded-tl-sm px-3.5 py-2.5 border border-white/10">
              <span className="w-1.5 h-1.5 rounded-full bg-gold inline-block mx-0.5 animate-bounce" />
              <span className="w-1.5 h-1.5 rounded-full bg-gold inline-block mx-0.5 animate-bounce" style={{ animationDelay: '0.2s' }} />
              <span className="w-1.5 h-1.5 rounded-full bg-gold inline-block mx-0.5 animate-bounce" style={{ animationDelay: '0.4s' }} />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="flex flex-wrap gap-1.5 justify-end pb-3">
        {SUGGESTIONS.map(s => (
          <button key={s} onClick={() => sendMessage(s)} className="bg-gold/10 border border-gold/30 rounded-full px-3 py-1 text-gold text-[12px] hover:bg-gold/20 transition-colors">
            {s}
          </button>
        ))}
      </div>

      <div className="flex gap-2.5 items-center pt-3 border-t border-white/10">
        <Input className="flex-1" placeholder="اسأل المساعد الذكي..." value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendMessage()} />
        <button onClick={() => sendMessage()} disabled={loading} className="w-10 h-10 rounded-lg bg-gradient-to-br from-gold to-amber-700 text-white flex items-center justify-center hover:opacity-85 disabled:opacity-40">
          <Send size={16} />
        </button>
        <button onClick={handlePrint} className="w-10 h-10 rounded-lg bg-gray-600 text-white flex items-center justify-center hover:opacity-85" title="طباعة">
          <Printer size={16} />
        </button>
      </div>
    </div>
  );
};
