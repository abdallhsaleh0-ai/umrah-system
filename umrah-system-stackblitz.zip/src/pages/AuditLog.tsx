import React from 'react';
import { useAuth } from '../hooks/useAuth';
import { useDataStore } from '../context/DataContext';
import { EmptyState, Table, TableHead, TableHeader, TableBody, TableRow, TableCell } from '../components/UI';
import { actionLabel, esc } from '../utils/helpers';

export const AuditLog: React.FC = () => {
  const { canEdit } = useAuth();
  const { auditLog } = useDataStore();

  const recentLogs = auditLog.slice(0, 200);

  if (!canEdit()) {
    return <div className="bg-navy-2 border border-white/10 rounded-xl p-4"><EmptyState icon="🔒" message="هذه الصفحة غير متاحة لدورك" /></div>;
  }

  return (
    <div className="bg-navy-2 border border-white/10 rounded-xl p-4">
      <h3 className="text-[13px] font-semibold mb-3">📜 سجل التعديلات (آخر {recentLogs.length} عملية)</h3>
      {recentLogs.length === 0 ? (
        <EmptyState icon="📜" message="لا يوجد سجل بعد" />
      ) : (
        <div className="overflow-x-auto">
          <Table>
            <TableHead>
              <TableHeader>التاريخ</TableHeader>
              <TableHeader>المستخدم</TableHeader>
              <TableHeader>الإجراء</TableHeader>
              <TableHeader>النوع</TableHeader>
              <TableHeader>العنصر</TableHeader>
            </TableHead>
            <TableBody>
              {recentLogs.map((log, i) => (
                <TableRow key={log.id} even={i % 2 === 0}>
                  <TableCell className="text-muted text-[11px]">{new Date(log.time).toLocaleString('ar-EG')}</TableCell>
                  <TableCell className="text-gold text-[12px]">{esc(log.user)}</TableCell>
                  <TableCell>{actionLabel(log.action)}</TableCell>
                  <TableCell className="text-teal text-[12px]">{esc(log.entityType)}</TableCell>
                  <TableCell><b className="text-white">{esc(log.entityName)}</b></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};
