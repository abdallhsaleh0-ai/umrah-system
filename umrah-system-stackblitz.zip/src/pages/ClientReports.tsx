import React from 'react';
import { useAuth } from '../hooks/useAuth';
import { useDataStore } from '../context/DataContext';
import { EmptyState, Table, TableHead, TableHeader, TableBody, TableRow, TableCell, Button } from '../components/UI';
import { esc } from '../utils/helpers';

export const ClientReports: React.FC = () => {
  const { canPrint } = useAuth();
  const { flights, clients, pilgrims } = useDataStore();

  const activeClients = clients.filter(c => !c.deleted);
  const activeFlights = flights.filter(f => !f.deleted);

  if (!activeClients.length) {
    return <div className="bg-navy-2 border border-white/10 rounded-xl p-4"><EmptyState icon="📄" message="لا يوجد عملاء لعرض تقاريرهم" /></div>;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-3.5">
        <span className="text-muted text-[13px]">📄 {activeClients.length} عميل</span>
        {canPrint() && <Button variant="purple" size="sm" className="flex items-center gap-1">🖨️ طباعة كل التقارير</Button>}
      </div>

      <div className="bg-navy-2 border border-white/10 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHead>
              <TableHeader>الكود</TableHeader>
              <TableHeader>الاسم</TableHeader>
              <TableHeader>الهاتف</TableHeader>
              <TableHeader>المدينة</TableHeader>
              <TableHeader>الرحلة</TableHeader>
              <TableHeader>المعتمرين</TableHeader>
              <TableHeader>توزيع النوع</TableHeader>
              <TableHeader>الحالة</TableHeader>
              <TableHeader>الفنادق/الغرف</TableHeader>
              <TableHeader>إجراءات</TableHeader>
            </TableHead>
            <TableBody>
              {activeClients.map((c, i) => {
                const pils = pilgrims.filter(p => !p.deleted && p.clientCode === c.code && p.flightId === c.flightId);
                const fl = activeFlights.find(f => f.id === c.flightId);
                const male = pils.filter(p => p.gender === 'ذكر').length;
                const female = pils.filter(p => p.gender === 'أنثى').length;
                const children = pils.filter(p => p.gender === 'طفل').length;
                const infants = pils.filter(p => p.gender === 'رضيع').length;
                const completed = pils.filter(p => p.status === 'مكتمل').length;
                const incomplete = pils.filter(p => p.status === 'ناقص مستندات').length;
                const pending = pils.filter(p => p.status === 'معلق').length;

                const hotels: Record<string, number> = {};
                pils.forEach(p => { if (p.hotel) hotels[p.hotel] = (hotels[p.hotel] || 0) + 1; });
                const hotelStr = Object.keys(hotels).map(h => `${h}: ${hotels[h]}`).join(' | ') || '-';

                return (
                  <TableRow key={c.id} even={i % 2 === 0}>
                    <TableCell><b className="text-gold">{esc(c.code)}</b></TableCell>
                    <TableCell><b className="text-white">{esc(c.name)}</b></TableCell>
                    <TableCell>{esc(c.phone)}</TableCell>
                    <TableCell>{esc(c.city)}</TableCell>
                    <TableCell className="text-teal">{esc(fl?.name || '-')}</TableCell>
                    <TableCell className="text-green font-semibold">{pils.length}</TableCell>
                    <TableCell className="text-[12px] text-muted">👨{male} 👩{female} 🧒{children} 👶{infants}</TableCell>
                    <TableCell className="text-[11px] text-muted">✅{completed} ⚠️{incomplete} 🔴{pending}</TableCell>
                    <TableCell className="text-[11px] text-muted">{hotelStr}</TableCell>
                    <TableCell>
                      {canPrint() && (
                        <div className="flex gap-1">
                          <button className="bg-purple text-white rounded-md px-1.5 py-1 text-[11px] hover:opacity-85">🖨️</button>
                          <button className="bg-gold text-navy rounded-md px-1.5 py-1 text-[11px] hover:opacity-85">📥</button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
};
