import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useDataStore } from '../context/DataContext';
import { KPI } from '../components/UI/KPI';
import { Alert } from '../components/UI/Alert';
import { GenderChart, HotelChart, StatusChart, SeatsChart } from '../components/Charts';
import { Plane, Users, UserCheck, AlertTriangle } from 'lucide-react';
import { daysLeft } from '../utils/helpers';

export const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { pilgrims, flights, clients } = useDataStore();

  const activePilgrims = pilgrims.filter(p => !p.deleted && p.status !== 'ملغي');
  const activeFlights = flights.filter(f => !f.deleted);
  const activeClients = clients.filter(c => !c.deleted);

  const stats = {
    male: activePilgrims.filter(p => p.gender === 'ذكر').length,
    female: activePilgrims.filter(p => p.gender === 'أنثى').length,
    children: activePilgrims.filter(p => p.gender === 'طفل').length,
    infants: activePilgrims.filter(p => p.gender === 'رضيع').length,
    incomplete: activePilgrims.filter(p => p.status === 'ناقص مستندات').length,
    pending: activePilgrims.filter(p => p.status === 'معلق').length,
    completed: activePilgrims.filter(p => p.status === 'مكتمل').length,
  };

  const expiredPassports = activePilgrims.filter(p => p.expiry && new Date(p.expiry) < new Date());
  const soonPassports = activePilgrims.filter(p => {
    if (!p.expiry) return false;
    const days = (new Date(p.expiry).getTime() - Date.now()) / 86400000;
    return days > 0 && days < 180;
  });
  const upcomingFlights = activeFlights.filter(f => {
    const d = daysLeft(f.date);
    return d > 0 && d <= 30;
  });

  return (
    <div className="space-y-4">
      {/* Alerts */}
      <div className="flex flex-wrap gap-2">
        {expiredPassports.length > 0 && (
          <Alert type="danger" count={expiredPassports.length} label="جوازات منتهية" onClick={() => navigate('/pilgrims')} />
        )}
        {soonPassports.length > 0 && (
          <Alert type="warning" count={soonPassports.length} label="جوازات تنتهي قريباً" onClick={() => navigate('/pilgrims')} />
        )}
        {stats.incomplete > 0 && (
          <Alert type="warning" count={stats.incomplete} label="ناقصو مستندات" onClick={() => navigate('/pilgrims')} />
        )}
        {upcomingFlights.length > 0 && (
          <Alert type="info" count={upcomingFlights.length} label="رحلات خلال 30 يوم" onClick={() => navigate('/flights')} />
        )}
        {expiredPassports.length === 0 && soonPassports.length === 0 && stats.incomplete === 0 && upcomingFlights.length === 0 && (
          <Alert type="success" label="كل شيء على ما يرام! لا توجد تنبيهات" />
        )}
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
        <KPI icon={<Plane size={28} />} label="الرحلات" value={activeFlights.length} color="text-teal" trend="up" trendValue={`+${activeFlights.length}`} onClick={() => navigate('/flights')} />
        <KPI icon={<Users size={28} />} label="العملاء" value={activeClients.length} color="text-gold" trend="up" trendValue={`+${activeClients.length}`} onClick={() => navigate('/clients')} />
        <KPI icon={<UserCheck size={28} />} label="المعتمرين" value={activePilgrims.length} color="text-green" trend="up" trendValue={`+${activePilgrims.length}`} onClick={() => navigate('/pilgrims')} />
        <KPI icon={<AlertTriangle size={28} />} label="ناقص مستندات" value={stats.incomplete} color="text-amber" trend={stats.incomplete ? 'down' : 'neutral'} trendValue={stats.incomplete ? 'تنبيه' : 'لا يوجد'} onClick={() => navigate('/pilgrims')} />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5">
        <div className="bg-navy-2 border border-white/10 rounded-xl p-4">
          <h3 className="text-[13px] font-semibold mb-3.5">👥 توزيع النوع</h3>
          <div className="h-[200px]">
            <GenderChart data={[stats.male, stats.female, stats.children, stats.infants]} />
          </div>
          <div className="flex justify-around mt-2.5 text-xs text-muted">
            <span>👨 ذكور: {stats.male}</span>
            <span>👩 إناث: {stats.female}</span>
            <span>🧒 أطفال: {stats.children}</span>
            <span>👶 رضع: {stats.infants}</span>
          </div>
        </div>

        <div className="bg-navy-2 border border-white/10 rounded-xl p-4">
          <h3 className="text-[13px] font-semibold mb-3.5">🏨 توزيع الفنادق</h3>
          <div className="h-[200px]">
            <HotelChart pilgrims={activePilgrims} />
          </div>
        </div>

        <div className="bg-navy-2 border border-white/10 rounded-xl p-4">
          <h3 className="text-[13px] font-semibold mb-3.5">📋 حالة المستندات</h3>
          <div className="h-[200px]">
            <StatusChart data={[stats.completed, stats.incomplete, stats.pending]} />
          </div>
        </div>

        <div className="bg-navy-2 border border-white/10 rounded-xl p-4">
          <h3 className="text-[13px] font-semibold mb-3.5">✈️ مقاعد الرحلات</h3>
          <div className="h-[200px]">
            <SeatsChart flights={activeFlights} pilgrims={activePilgrims} />
          </div>
        </div>
      </div>

      {/* Summary */}
      <div className="bg-navy-2 border border-white/10 rounded-xl p-4">
        <h3 className="text-[13px] font-semibold mb-3.5">📊 ملخص سريع</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 text-[13px]">
          <div><span className="text-muted">👨 ذكور:</span> <b className="text-teal">{stats.male}</b></div>
          <div><span className="text-muted">👩 إناث:</span> <b className="text-purple">{stats.female}</b></div>
          <div><span className="text-muted">🧒 أطفال:</span> <b className="text-amber">{stats.children}</b></div>
          <div><span className="text-muted">👶 رضع:</span> <b className="text-rose">{stats.infants}</b></div>
          <div><span className="text-muted">✅ مكتمل:</span> <b className="text-green">{stats.completed}</b></div>
          <div><span className="text-muted">⚠️ ناقص:</span> <b className="text-amber">{stats.incomplete}</b></div>
          <div><span className="text-muted">🔴 معلق:</span> <b className="text-rose">{stats.pending}</b></div>
          <div><span className="text-muted">🗑️ محذوف:</span> <b className="text-muted">{pilgrims.filter(x => x.deleted).length}</b></div>
        </div>
      </div>
    </div>
  );
};
