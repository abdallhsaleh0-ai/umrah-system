import React from 'react';
import { useAuth } from '../hooks/useAuth';
import { useDataStore } from '../context/DataContext';
import { EmptyState, Table, TableHead, TableHeader, TableBody, TableRow, TableCell } from '../components/UI';
import { esc } from '../utils/helpers';

export const Trash: React.FC = () => {
  const { canEdit, isAdmin } = useAuth();
  const { flights, clients, pilgrims, restoreFlight, restoreClient, restorePilgrim, permanentDelete } = useDataStore();

  const deletedItems = [
    ...flights.filter(f => f.deleted).map(f => ({ type: 'flights' as const, typeLabel: '✈️ رحلة', ...f })),
    ...clients.filter(c => c.deleted).map(c => ({ type: 'clients' as const, typeLabel: '👤 عميل', ...c })),
    ...pilgrims.filter(p => p.deleted).map(p => ({ type: 'pilgrims' as const, typeLabel: '🗂️ معتمر', ...p })),
  ].sort((a, b) => new Date(b.deletedAt || 0).getTime() - new Date(a.deletedAt || 0).getTime());

  const handleRestore = (type: 'flights' | 'clients' | 'pilgrims', id: string) => {
    const userEmail = useDataStore.getState().currentUser;
    if (type === 'flights') restoreFlight(id, userEmail);
    else if (type === 'clients') restoreClient(id, userEmail);
    else restorePilgrim(id, userEmail);
  };

  const handlePermanentDelete = (type: 'flights' | 'clients' | 'pilgrims', id: string, name: string) => {
    if (!confirm('⚠️ حذف نهائي! لا يمكن التراجع. متابعة؟')) return;
    permanentDelete(type, id, useDataStore.getState().currentUser);
  };

  return (
    <div className="bg-navy-2 border border-white/10 rounded-xl p-4">
      <h3 className="text-[13px] font-semibold mb-3">🗑️ الأرشيف — {deletedItems.length} عنصر محذوف</h3>
      {deletedItems.length === 0 ? (
        <EmptyState icon="🗑️" message="الأرشيف فارغ" />
      ) : (
        <div className="overflow-x-auto">
          <Table>
            <TableHead>
              <TableHeader>النوع</TableHeader>
              <TableHeader>الاسم</TableHeader>
              <TableHeader>تاريخ الحذف</TableHeader>
              <TableHeader>بواسطة</TableHeader>
              <TableHeader>إجراءات</TableHeader>
            </TableHead>
            <TableBody>
              {deletedItems.map((item, i) => (
                <TableRow key={`${item.type}-${item.id}`} even={i % 2 === 0}>
                  <TableCell>{item.typeLabel}</TableCell>
                  <TableCell><b className="text-white">{esc((item as any).name || (item as any).code || '—')}</b></TableCell>
                  <TableCell className="text-muted text-[12px]">{item.deletedAt ? new Date(item.deletedAt).toLocaleString('ar-EG') : '-'}</TableCell>
                  <TableCell className="text-muted text-[12px]">{esc(item.deletedBy || '-')}</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {canEdit() && (
                        <button onClick={() => handleRestore(item.type, item.id)} className="bg-green text-white rounded-md px-2 py-1 text-[11px] hover:opacity-85">♻️ استرجاع</button>
                      )}
                      {isAdmin() && (
                        <button onClick={() => handlePermanentDelete(item.type, item.id, (item as any).name || (item as any).code || '')} className="bg-rose text-white rounded-md px-2 py-1 text-[11px] hover:opacity-85">❌ نهائي</button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};
