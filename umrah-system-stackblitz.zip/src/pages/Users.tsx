import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { db } from '../firebase/config';
import { collection, getDocs, doc, setDoc } from 'firebase/firestore';
import { EmptyState, Table, TableHead, TableHeader, TableBody, TableRow, TableCell, Select } from '../components/UI';
import { roleLabel, roleClass, esc } from '../utils/helpers';
import clsx from 'clsx';

interface FirebaseUser {
  uid: string;
  email: string;
  role: string;
  createdAt?: any;
}

export const Users: React.FC = () => {
  const { isAdmin, user: currentUser } = useAuth();
  const [users, setUsers] = useState<FirebaseUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAdmin()) return;
    const loadUsers = async () => {
      try {
        const snap = await getDocs(collection(db, 'users'));
        const list = snap.docs.map(d => ({ uid: d.id, ...d.data() } as FirebaseUser));
        setUsers(list);
      } catch (e) {
        console.error(e);
      }
      setLoading(false);
    };
    loadUsers();
  }, [isAdmin]);

  const handleRoleChange = async (uid: string, role: string) => {
    try {
      await setDoc(doc(db, 'users', uid), { role }, { merge: true });
      setUsers(prev => prev.map(u => u.uid === uid ? { ...u, role } : u));
    } catch (e) {
      alert('فشل تحديث الدور');
    }
  };

  if (!isAdmin()) {
    return <div className="bg-navy-2 border border-white/10 rounded-xl p-4"><EmptyState icon="🔒" message="هذه الصفحة للمدير فقط" /></div>;
  }

  if (loading) {
    return <div className="bg-navy-2 border border-white/10 rounded-xl p-4"><EmptyState icon="⏳" message="جاري تحميل المستخدمين..." /></div>;
  }

  return (
    <div className="bg-navy-2 border border-white/10 rounded-xl p-4">
      <h3 className="text-[13px] font-semibold mb-3">👥 إدارة المستخدمين</h3>
      {users.length === 0 ? (
        <EmptyState icon="👥" message="لا يوجد مستخدمون مسجلون" />
      ) : (
        <div className="overflow-x-auto">
          <Table>
            <TableHead>
              <TableHeader>البريد</TableHeader>
              <TableHeader>الدور</TableHeader>
              <TableHeader>تاريخ التسجيل</TableHeader>
              <TableHeader>تغيير الدور</TableHeader>
            </TableHead>
            <TableBody>
              {users.map((u, i) => (
                <TableRow key={u.uid} even={i % 2 === 0}>
                  <TableCell><b className="text-white">{esc(u.email)}</b></TableCell>
                  <TableCell>
                    <span className={clsx('text-[10px] px-2 py-0.5 rounded-full font-bold', roleClass(u.role))}>
                      {roleLabel(u.role)}
                    </span>
                  </TableCell>
                  <TableCell className="text-muted text-[11px]">{u.createdAt?.toDate?.().toLocaleDateString('ar-EG') || '-'}</TableCell>
                  <TableCell>
                    {u.uid !== currentUser?.uid ? (
                      <Select 
                        options={[
                          { value: 'user', label: 'مستخدم' },
                          { value: 'admin', label: 'مدير' },
                          { value: 'supervisor', label: 'مشرف رحلة' },
                        ]}
                        value={u.role}
                        onChange={e => handleRoleChange(u.uid, e.target.value)}
                        className="w-[110px] inline-block"
                      />
                    ) : (
                      <span className="text-muted text-[11px]">(أنت)</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};
