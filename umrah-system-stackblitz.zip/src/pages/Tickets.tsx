import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useDataStore } from '../context/DataContext';
import { Button, Select, EmptyState, Table, TableHead, TableHeader, TableBody, TableRow, TableCell, GenderBadge } from '../components/UI';
import { esc } from '../utils/helpers';
import { Printer } from 'lucide-react';

export const Tickets: React.FC = () => {
  const { canPrint } = useAuth();
  const { flights, pilgrims } = useDataStore();
  const [selectedFlight, setSelectedFlight] = useState('');

  const activeFlights = flights.filter(f => !f.deleted);
  const activePilgrims = pilgrims.filter(p => !p.deleted && p.status !== 'ملغي');

  const flightOptions = [{ value: '', label: 'اختر رحلة' }, ...activeFlights.map(f => ({ value: f.id, label: f.name }))];
  const currentFlight = activeFlights.find(f => f.id === selectedFlight);
  const flightPilgrims = selectedFlight ? activePilgrims.filter(p => p.flightId === selectedFlight) : [];

  return (
    <div>
      <div className="flex items-center gap-2 mb-3.5 flex-wrap">
        <Select className="w-[240px]" options={flightOptions} value={selectedFlight} onChange={e => setSelectedFlight(e.target.value)} />
        <div className="flex-1" />
        <span className="text-muted text-[12px]">{flightPilgrims.length} تذكرة</span>
        {canPrint() && (
          <Button variant="purple" size="sm" disabled={!selectedFlight} className="flex items-center gap-1">
            <Printer size={12} /> طباعة التذاكر
          </Button>
        )}
      </div>

      <div className="bg-navy-2 border border-white/10 rounded-xl p-4">
        <h3 className="text-[13px] font-semibold mb-3">🎫 تذاكر رحلة: {currentFlight ? `${esc(currentFlight.name)} — ${esc(currentFlight.date)}` : 'لم تُختر رحلة'}</h3>
        {flightPilgrims.length === 0 ? (
          <EmptyState icon="🎫" message={selectedFlight ? 'لا يوجد معتمرون في هذه الرحلة' : 'اختر رحلة لعرض التذاكر'} />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHead>
                <TableHeader>الاسم</TableHeader>
                <TableHeader>رقم الجواز</TableHeader>
                <TableHeader>النوع</TableHeader>
                <TableHeader>تاريخ الميلاد</TableHeader>
                <TableHeader>تاريخ الانتهاء</TableHeader>
                <TableHeader>الجنسية</TableHeader>
              </TableHead>
              <TableBody>
                {flightPilgrims.map((p, i) => (
                  <TableRow key={p.id} even={i % 2 === 0}>
                    <TableCell><b className="text-white">{esc(p.name)}</b></TableCell>
                    <TableCell className="font-mono text-muted text-[12px]">{esc(p.passport)}</TableCell>
                    <TableCell><GenderBadge gender={p.gender} /></TableCell>
                    <TableCell>{esc(p.birth || '-')}</TableCell>
                    <TableCell>{esc(p.expiry || '-')}</TableCell>
                    <TableCell>{esc(p.nationality || '-')}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </div>
  );
};
