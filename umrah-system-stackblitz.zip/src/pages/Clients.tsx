import React, { useState, useMemo } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useDataStore } from '../context/DataContext';
import { Button, Modal, Input, Select, EmptyState, Table, TableHead, TableHeader, TableBody, TableRow, TableCell } from '../components/UI';
import { uid, esc } from '../utils/helpers';
import { validateClient } from '../utils/validators';
import { Plus, Printer, Edit, Trash2 } from 'lucide-react';

export const Clients: React.FC = () => {
  const { canEdit, canPrint } = useAuth();
  const { flights, clients, pilgrims, addClient, updateClient, deleteClient } = useDataStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [flightFilter, setFlightFilter] = useState('');
  const [formData, setFormData] = useState({ code: '', name: '', phone: '', city: '', flightId: '' });
  const [errors, setErrors] = useState<string[]>([]);

  const activeFlights = flights.filter(f => !f.deleted);
  const activeClients = clients.filter(c => !c.deleted);

  const filteredClients = useMemo(() => {
    return activeClients.filter(c => {
      if (search && !c.name.includes(search) && !c.code.includes(search) && !c.city.includes(search)) return false;
      if (flightFilter && c.flightId !== flightFilter) return false;
      return true;
    });
  }, [activeClients, search, flightFilter]);

  const handleOpenAdd = () => {
    setEditId(null);
    setFormData({ code: `CL${String(activeClients.length + 1).padStart(3, '0')}`, name: '', phone: '', city: '', flightId: '' });
    setErrors([]);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (client: typeof activeClients[0]) => {
    setEditId(client.id);
    setFormData({ code: client.code, name: client.name, phone: client.phone, city: client.city, flightId: client.flightId || '' });
    setErrors([]);
    setIsModalOpen(true);
  };

  const handleSave = () => {
    const errs = validateClient(formData.name, formData.flightId || null, formData.code, activeClients, editId);
    if (errs.length) {
      setErrors(errs);
      return;
    }

    const userEmail = useDataStore.getState().currentUser;
    const data = { ...formData, flightId: formData.flightId || null };

    if (editId) {
      updateClient(editId, data, userEmail);
    } else {
      addClient({ id: uid(), ...data, deleted: false }, userEmail);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (confirm(`نقل "${name}" إلى الأرشيف؟`)) {
      deleteClient(id, useDataStore.getState().currentUser);
    }
  };

  const flightOptions = [
    { value: '', label: 'كل الرحلات' },
    ...activeFlights.map(f => ({ value: f.id, label: f.name }))
  ];

  const clientFlightOptions = [
    { value: '', label: '-- بدون رحلة --' },
    ...activeFlights.map(f => ({ value: f.id, label: f.name }))
  ];

  return (
    <div>
      <div className="flex items-center gap-2 mb-3.5 flex-wrap">
        <Input 
          className="w-[170px]" 
          placeholder="بحث بالاسم/الكود/المدينة" 
          value={search} 
          onChange={e => setSearch(e.target.value)} 
        />
        <Select className="w-[170px]" options={flightOptions} value={flightFilter} onChange={e => setFlightFilter(e.target.value)} />
        <div className="flex-1" />
        <span className="text-muted text-[12px]">{filteredClients.length} عميل</span>
        {canEdit() && (
          <Button variant="gold" onClick={handleOpenAdd} className="flex items-center gap-1">
            <Plus size={14} /> إضافة عميل
          </Button>
        )}
      </div>

      {filteredClients.length === 0 ? (
        <EmptyState icon="👤" message={activeClients.length === 0 ? "لا يوجد عملاء بعد" : "لا توجد نتائج"} />
      ) : (
        <div className="bg-navy-2 border border-white/10 rounded-xl overflow-hidden">
          <Table>
            <TableHead>
              <TableHeader>الكود</TableHeader>
              <TableHeader>الاسم</TableHeader>
              <TableHeader>الهاتف</TableHeader>
              <TableHeader>المدينة</TableHeader>
              <TableHeader>الرحلة</TableHeader>
              <TableHeader>المعتمرين</TableHeader>
              <TableHeader>إجراءات</TableHeader>
            </TableHead>
            <TableBody>
              {filteredClients.map((c, i) => {
                const fl = activeFlights.find(f => f.id === c.flightId);
                const cnt = pilgrims.filter(p => !p.deleted && p.clientCode === c.code && p.flightId === c.flightId).length;
                return (
                  <TableRow key={c.id} even={i % 2 === 0}>
                    <TableCell><b className="text-gold">{esc(c.code)}</b></TableCell>
                    <TableCell><b className="text-white">{esc(c.name)}</b></TableCell>
                    <TableCell>{esc(c.phone)}</TableCell>
                    <TableCell>{esc(c.city)}</TableCell>
                    <TableCell className="text-teal">{esc(fl?.name || '-')}</TableCell>
                    <TableCell className="text-green font-semibold">{cnt}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        {canPrint() && (
                          <button className="bg-purple text-white rounded-md px-1.5 py-1 text-[11px] hover:opacity-85">
                            <Printer size={12} />
                          </button>
                        )}
                        {canEdit() && (
                          <>
                            <button onClick={() => handleOpenEdit(c)} className="bg-teal text-white rounded-md px-1.5 py-1 text-[11px] hover:opacity-85">
                              <Edit size={12} />
                            </button>
                            <button onClick={() => handleDelete(c.id, c.name)} className="bg-rose text-white rounded-md px-1.5 py-1 text-[11px] hover:opacity-85">
                              <Trash2 size={12} />
                            </button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editId ? '✏️ تعديل بيانات العميل' : '👤 إضافة عميل جديد'}
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsModalOpen(false)}>إلغاء</Button>
            <Button variant="gold" onClick={handleSave}>{editId ? 'حفظ التعديل' : 'إضافة'}</Button>
          </>
        }
      >
        {errors.length > 0 && (
          <div className="bg-rose/10 border border-rose/30 rounded-lg p-2.5 mb-3 text-rose text-xs">
            {errors.map((e, i) => <div key={i}>⚠️ {e}</div>)}
          </div>
        )}
        <div className="grid grid-cols-2 gap-3">
          <Input label="كود العميل" value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value })} />
          <Input label="اسم العميل *" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} />
          <Input label="رقم الهاتف" value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} />
          <Input label="المدينة" value={formData.city} onChange={e => setFormData({ ...formData, city: e.target.value })} />
        </div>
        <div className="mt-3">
          <Select label="الرحلة (اختياري)" options={clientFlightOptions} value={formData.flightId} onChange={e => setFormData({ ...formData, flightId: e.target.value })} />
        </div>
      </Modal>
    </div>
  );
};
