import React from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { Flight, Pilgrim } from '../../types';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

interface Props {
  flights: Flight[];
  pilgrims: Pilgrim[];
}

export const SeatsChart: React.FC<Props> = ({ flights, pilgrims }) => {
  if (!flights.length) {
    return (
      <Bar
        data={{
          labels: ['لا توجد رحلات'],
          datasets: [{ data: [0], backgroundColor: ['#94A3B8'] }],
        }}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            x: { beginAtZero: true, ticks: { color: '#94A3B8' } },
            y: { ticks: { color: '#94A3B8' } },
          },
        }}
      />
    );
  }

  const flightNames = flights.map(f => f.name.length > 12 ? f.name.slice(0, 12) + '...' : f.name);
  const totalSeats = flights.map(f => f.seats || 45);
  const occupied = flights.map(f => pilgrims.filter(p => p.flightId === f.id).length);
  const available = flights.map((f, i) => totalSeats[i] - occupied[i]);

  return (
    <Bar
      data={{
        labels: flightNames,
        datasets: [
          {
            label: 'مشغول',
            data: occupied,
            backgroundColor: 'rgba(10,115,115,0.8)',
            borderRadius: 4,
          },
          {
            label: 'متاح',
            data: available,
            backgroundColor: 'rgba(201,168,76,0.6)',
            borderRadius: 4,
          },
        ],
      }}
      options={{
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            labels: { color: '#94A3B8', font: { size: 10 } },
          },
        },
        scales: {
          x: {
            stacked: true,
            beginAtZero: true,
            ticks: { color: '#94A3B8', font: { size: 9 } },
            grid: { color: 'rgba(255,255,255,0.05)' },
          },
          y: {
            stacked: true,
            ticks: { color: '#94A3B8', font: { size: 9 } },
            grid: { display: false },
          },
        },
      }}
    />
  );
};
