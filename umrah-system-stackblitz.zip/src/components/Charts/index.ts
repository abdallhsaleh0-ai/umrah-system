export { GenderChart } from './GenderChart';
export { HotelChart } from './HotelChart';
export { StatusChart } from './StatusChart';
export { SeatsChart } from './SeatsChart';
