import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend);

interface Props {
  data: number[];
}

export const GenderChart: React.FC<Props> = ({ data }) => {
  return (
    <Doughnut
      data={{
        labels: ['ذكور', 'إناث', 'أطفال', 'رضع'],
        datasets: [{
          data,
          backgroundColor: ['#0A7373', '#7C3AED', '#D97706', '#E11D48'],
          borderColor: ['#0A7373', '#7C3AED', '#D97706', '#E11D48'],
          borderWidth: 2,
        }],
      }}
      options={{
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: '#94A3B8', font: { size: 11 } },
          },
        },
      }}
    />
  );
};
