import React from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { Pilgrim } from '../../types';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

interface Props {
  pilgrims: Pilgrim[];
}

export const HotelChart: React.FC<Props> = ({ pilgrims }) => {
  const hotels: Record<string, number> = {};
  pilgrims.forEach(p => { if (p.hotel) hotels[p.hotel] = (hotels[p.hotel] || 0) + 1; });
  const hotelKeys = Object.keys(hotels).sort((a, b) => hotels[b] - hotels[a]);
  const colors = ['#0A7373', '#C9A84C', '#7C3AED', '#16A34A', '#E11D48', '#D97706'];

  if (!hotelKeys.length) {
    return (
      <Bar
        data={{
          labels: ['لا توجد فنادق'],
          datasets: [{ data: [0], backgroundColor: ['#94A3B8'] }],
        }}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            y: { beginAtZero: true, ticks: { color: '#94A3B8' } },
            x: { ticks: { color: '#94A3B8' } },
          },
        }}
      />
    );
  }

  return (
    <Bar
      data={{
        labels: hotelKeys,
        datasets: [{
          label: 'عدد المعتمرين',
          data: hotelKeys.map(k => hotels[k]),
          backgroundColor: hotelKeys.map((_, i) => colors[i % colors.length]),
          borderRadius: 6,
        }],
      }}
      options={{
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { color: '#94A3B8', font: { size: 10 } },
            grid: { color: 'rgba(255,255,255,0.05)' },
          },
          x: {
            ticks: { color: '#94A3B8', font: { size: 10 } },
            grid: { display: false },
          },
        },
      }}
    />
  );
};
