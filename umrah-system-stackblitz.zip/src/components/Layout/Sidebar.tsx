import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useDataStore } from '../../context/DataContext';
import { NAV_ITEMS } from '../../constants';
import { roleLabel, roleClass } from '../../utils/helpers';
import { X } from 'lucide-react';
import clsx from 'clsx';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout, isAdmin } = useAuth();
  const { pilgrims, flights } = useDataStore();

  const activeCount = pilgrims.filter(p => !p.deleted && p.status !== 'ملغي').length;
  const flightCount = flights.filter(f => !f.deleted).length;

  const visibleNav = NAV_ITEMS.filter(n => !n.adminOnly || isAdmin());

  return (
    <>
      <div 
        className={clsx(
          "fixed inset-0 bg-black/55 z-40 transition-opacity lg:hidden",
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
        onClick={onClose}
      />

      <aside className={clsx(
        "fixed right-0 top-0 bottom-0 w-[280px] max-w-[80vw] bg-navy-2 border-l border-white/10 z-50 flex flex-col transition-transform duration-250 lg:static lg:transform-none",
        isOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"
      )}>
        <div className="p-4 pb-2.5 border-b border-white/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-gold font-bold text-[15px]">
              <span className="text-2xl">🕋</span>
              نظام العمرة
            </div>
            <button onClick={onClose} className="lg:hidden text-white/60 hover:text-white">
              <X size={20} />
            </button>
          </div>
          <div className="text-muted text-[10px] mt-1">{user?.email}</div>
          <span className={clsx("inline-block mt-1.5 text-[10px] px-2 py-0.5 rounded-full font-bold", roleClass(user?.role || 'guest'))}>
            {roleLabel(user?.role || 'guest')}
          </span>
        </div>

        <nav className="flex-1 py-1.5 overflow-y-auto">
          {visibleNav.map(item => {
            const isActive = location.pathname === `/${item.id}`;
            return (
              <button
                key={item.id}
                onClick={() => { navigate(`/${item.id}`); onClose(); }}
                className={clsx(
                  "w-full flex items-center gap-2.5 px-4 py-2.5 text-[13px] transition-all border-r-[3px]",
                  isActive 
                    ? "bg-gold/15 border-r-gold text-gold font-semibold" 
                    : "border-r-transparent text-muted hover:bg-white/5 hover:text-white"
                )}
              >
                <span className="text-base">{item.icon}</span>
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/10">
          <button 
            onClick={logout}
            className="w-full bg-rose/15 border border-rose/30 text-rose rounded-lg py-1.5 text-[11px] font-medium hover:bg-rose/25 transition-colors"
          >
            🚪 تسجيل خروج
          </button>
          <div className="text-muted text-[10px] text-center mt-2">
            {activeCount} معتمر · {flightCount} رحلة
          </div>
        </div>
      </aside>
    </>
  );
};
