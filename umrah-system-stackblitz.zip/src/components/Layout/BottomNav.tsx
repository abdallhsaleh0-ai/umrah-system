import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { NAV_ITEMS } from '../../constants';
import clsx from 'clsx';

export const BottomNav: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { isAdmin } = useAuth();

  const visibleNav = NAV_ITEMS.filter(n => n.bn && (!n.adminOnly || isAdmin()));

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-navy-2 border-t border-white/10 z-[140] py-1 flex">
      {visibleNav.map(item => {
        const isActive = location.pathname === `/${item.id}`;
        return (
          <button
            key={item.id}
            onClick={() => navigate(`/${item.id}`)}
            className={clsx(
              "flex-1 text-center py-1.5 text-[9px] transition-colors",
              isActive ? "text-gold" : "text-muted"
            )}
          >
            <span className="text-[17px] block mb-0.5">{item.icon}</span>
            {item.label}
          </button>
        );
      })}
    </div>
  );
};
