import React from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useDataStore } from '../../context/DataContext';
import { NAV_ITEMS } from '../../constants';
import { Button } from '../UI/Button';
import { Menu, Package, RefreshCw, BarChart3 } from 'lucide-react';
import { ConnectionBar } from '../UI/ConnectionBar';

interface HeaderProps {
  onMenuClick: () => void;
  onBackupClick: () => void;
  onSyncClick: () => void;
  connStatus: { status: 'ok' | 'err' | 'loading'; message: string };
}

export const Header: React.FC<HeaderProps> = ({ onMenuClick, onBackupClick, onSyncClick, connStatus }) => {
  const location = useLocation();
  const { user } = useAuth();
  const { fbConnected } = useDataStore();

  const currentNav = NAV_ITEMS.find(n => `/${n.id}` === location.pathname) || NAV_ITEMS[0];

  return (
    <div className="flex-shrink-0">
      <div className="px-4 py-2.5 border-b border-white/10 bg-navy-2 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2.5">
          <button 
            onClick={onMenuClick}
            className="lg:hidden bg-white/10 rounded-lg p-1.5 text-white hover:bg-white/15"
          >
            <Menu size={18} />
          </button>
          <h1 className="text-white font-bold text-base">
            {currentNav.icon} {currentNav.label}
          </h1>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="flex items-center gap-1.5 text-[11px] text-muted">
            <span className={clsx("w-2 h-2 rounded-full", 
              connStatus.status === 'ok' ? 'bg-green shadow-[0_0_6px_#22c55e]' : 
              connStatus.status === 'err' ? 'bg-rose' : 'bg-gold animate-pulse'
            )} />
            {connStatus.message}
          </span>
          <Button variant="success" size="sm" onClick={onBackupClick} className="flex items-center gap-1">
            <Package size={12} /> نسخ احتياطي
          </Button>
          <Button variant="ghost" size="sm" onClick={onSyncClick} className="flex items-center gap-1">
            <RefreshCw size={12} />
          </Button>
          <Button variant="purple" size="sm" className="flex items-center gap-1">
            <BarChart3 size={12} /> تحديث
          </Button>
        </div>
      </div>

      {connStatus.status !== 'ok' && (
        <ConnectionBar status={connStatus.status} message={connStatus.message} />
      )}
    </div>
  );
};

import clsx from 'clsx';
