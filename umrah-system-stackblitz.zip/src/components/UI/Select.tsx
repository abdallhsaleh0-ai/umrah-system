import React, { forwardRef } from 'react';
import clsx from 'clsx';

interface SelectOption {
  value: string;
  label: string;
}

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  options: SelectOption[];
  error?: string;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(({ label, options, error, className, ...props }, ref) => {
  return (
    <div className="w-full">
      {label && <label className="block text-muted text-xs mb-1">{label}</label>}
      <select
        ref={ref}
        className={clsx(
          'bg-navy-3 border border-white/10 rounded-lg px-3 py-2 text-[13px] text-gray-200 outline-none focus:border-gold/50 transition-colors w-full cursor-pointer',
          error && 'border-rose/50',
          className
        )}
        {...props}
      >
        {options.map(opt => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
      {error && <p className="text-rose text-[11px] mt-1">{error}</p>}
    </div>
  );
});

Select.displayName = 'Select';
