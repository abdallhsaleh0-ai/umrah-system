import React from 'react';
import clsx from 'clsx';

interface AlertProps {
  type: 'danger' | 'warning' | 'success' | 'info';
  count?: number;
  label: string;
  onClick?: () => void;
}

export const Alert: React.FC<AlertProps> = ({ type, count, label, onClick }) => {
  const styles = {
    danger: 'bg-rose/10 border-rose/30 text-rose',
    warning: 'bg-amber/10 border-amber/30 text-amber',
    success: 'bg-green/10 border-green/30 text-green',
    info: 'bg-teal/10 border-teal/30 text-teal',
  };

  return (
    <div 
      onClick={onClick}
      className={clsx(
        'flex items-center gap-2 px-3.5 py-2 rounded-xl border text-[12px] flex-1 min-w-[180px] cursor-pointer',
        styles[type]
      )}
    >
      <span>{type === 'danger' ? '❌' : type === 'warning' ? '⚠️' : type === 'success' ? '✅' : '✈️'}</span>
      {count !== undefined && <span className="font-bold text-lg">{count}</span>}
      <span className="text-muted text-[11px]">{label}</span>
      {onClick && <span className="mr-auto text-gold font-semibold text-[11px] hover:underline">عرض →</span>}
    </div>
  );
};
