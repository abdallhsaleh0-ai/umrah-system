import React from 'react';
import clsx from 'clsx';

interface CardProps {
  children: React.ReactNode;
  className?: string;
}

export const Card: React.FC<CardProps> = ({ children, className }) => {
  return (
    <div className={clsx('bg-navy-2 border border-white/10 rounded-xl p-4', className)}>
      {children}
    </div>
  );
};
