import React, { forwardRef } from 'react';
import clsx from 'clsx';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(({ label, error, className, ...props }, ref) => {
  return (
    <div className="w-full">
      {label && <label className="block text-muted text-xs mb-1">{label}</label>}
      <input
        ref={ref}
        className={clsx(
          'bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-[13px] text-gray-200 outline-none focus:border-gold/50 transition-colors w-full',
          error && 'border-rose/50',
          className
        )}
        {...props}
      />
      {error && <p className="text-rose text-[11px] mt-1">{error}</p>}
    </div>
  );
});

Input.displayName = 'Input';
