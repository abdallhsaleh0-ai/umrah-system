import React from 'react';

export const LoadingScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-navy flex flex-col items-center justify-center z-[999]">
      <div className="w-11 h-11 border-4 border-gold/20 border-t-gold rounded-full animate-spin mb-4" />
      <div className="text-gold font-semibold text-base">جاري الاتصال بقاعدة البيانات...</div>
      <div className="text-muted text-xs mt-2">Firebase Firestore + Auth</div>
    </div>
  );
};
