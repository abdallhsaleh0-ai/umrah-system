import React from 'react';
import clsx from 'clsx';

interface KPIProps {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: string;
  trend: 'up' | 'down' | 'neutral';
  trendValue: string;
  onClick?: () => void;
}

export const KPI: React.FC<KPIProps> = ({ icon, label, value, color, trend, trendValue, onClick }) => {
  const trendClasses = {
    up: 'bg-green/15 text-green',
    down: 'bg-rose/15 text-rose',
    neutral: 'bg-white/10 text-muted',
  };

  return (
    <div 
      onClick={onClick}
      className={clsx(
        'bg-navy-2 border border-white/10 rounded-xl p-3.5 transition-all cursor-pointer hover:-translate-y-0.5 hover:shadow-lg hover:border-white/20',
        onClick && 'cursor-pointer'
      )}
    >
      <span className="text-[28px] block mb-1">{icon}</span>
      <div className={clsx('font-bold text-[22px]', color)}>{value}</div>
      <div className="text-muted text-[11px] mb-1">{label}</div>
      <span className={clsx('inline-block text-[11px] px-2 py-0.5 rounded-full', trendClasses[trend])}>
        {trendValue}
      </span>
    </div>
  );
};
