import React from 'react';
import clsx from 'clsx';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'success' | 'danger' | 'ghost' | 'gold' | 'purple' | 'teal';
  size?: 'sm' | 'md';
  children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({ 
  variant = 'primary', 
  size = 'md', 
  children, 
  className,
  ...props 
}) => {
  const variants = {
    primary: 'bg-teal text-white hover:opacity-85',
    secondary: 'bg-gold text-navy hover:opacity-85',
    success: 'bg-green text-white hover:opacity-85',
    danger: 'bg-rose text-white hover:opacity-85',
    ghost: 'bg-white/10 text-gray-200 hover:bg-white/15',
    gold: 'bg-gold text-navy hover:opacity-85',
    purple: 'bg-purple text-white hover:opacity-85',
    teal: 'bg-teal text-white hover:opacity-85',
  };

  const sizes = {
    sm: 'px-2 py-1 text-[11px] rounded-md',
    md: 'px-3.5 py-2 text-[13px] rounded-lg',
  };

  return (
    <button 
      className={clsx('font-semibold transition-opacity disabled:opacity-40 disabled:cursor-not-allowed', variants[variant], sizes[size], className)}
      {...props}
    >
      {children}
    </button>
  );
};
