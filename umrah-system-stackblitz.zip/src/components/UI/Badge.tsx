import React from 'react';
import clsx from 'clsx';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'neutral';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({ children, variant = 'default', className }) => {
  const variants = {
    default: 'bg-teal-light/20 text-teal',
    success: 'bg-green-light/20 text-green',
    warning: 'bg-amber-light/20 text-amber',
    danger: 'bg-rose-light/20 text-rose',
    info: 'bg-purple-light/20 text-purple',
    neutral: 'bg-white/10 text-muted',
  };

  return (
    <span className={clsx('inline-block rounded-full px-2.5 py-0.5 text-[11px] font-semibold', variants[variant], className)}>
      {children}
    </span>
  );
};

export const PassportBadge: React.FC<{ expiry?: string }> = ({ expiry }) => {
  if (!expiry) return <Badge variant="neutral">غير محدد</Badge>;
  const d = new Date(expiry).getTime() - Date.now();
  if (d < 0) return <Badge variant="danger">منتهي ❌</Badge>;
  if (d < 180 * 86400000) return <Badge variant="warning">ينتهي قريباً ⚠️</Badge>;
  return <Badge variant="success">ساري ✅</Badge>;
};

export const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const map: Record<string, string> = {
    'مكتمل': 'success',
    'ناقص مستندات': 'warning',
    'معلق': 'danger',
    'ملغي': 'neutral',
  };
  return <Badge variant={map[status] as any || 'neutral'}>{status}</Badge>;
};

export const GenderBadge: React.FC<{ gender: string }> = ({ gender }) => {
  const map: Record<string, string> = {
    'ذكر': 'default',
    'أنثى': 'info',
    'طفل': 'warning',
    'رضيع': 'danger',
  };
  return <Badge variant={map[gender] as any || 'neutral'}>{gender}</Badge>;
};

export const HotelBadge: React.FC<{ hotel?: string }> = ({ hotel }) => {
  if (!hotel) return <Badge variant="neutral">غير محدد</Badge>;
  return <Badge variant="default">🏨 {hotel}</Badge>;
};

export const DaysBadge: React.FC<{ days: number }> = ({ days }) => {
  if (days > 30) return <Badge variant="success">{days} يوم</Badge>;
  if (days > 0) return <Badge variant="warning">{days} يوم</Badge>;
  return <Badge variant="danger">انتهت</Badge>;
};
