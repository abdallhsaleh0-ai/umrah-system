import React from 'react';
import clsx from 'clsx';

interface ConnectionBarProps {
  status: 'ok' | 'err' | 'loading';
  message: string;
}

export const ConnectionBar: React.FC<ConnectionBarProps> = ({ status, message }) => {
  const styles = {
    ok: 'bg-green/15 text-green',
    err: 'bg-rose/15 text-rose',
    loading: 'bg-gold/15 text-gold',
  };

  return (
    <div className={clsx('px-4 py-1.5 text-[11px] font-semibold text-center', styles[status])}>
      {message}
    </div>
  );
};
