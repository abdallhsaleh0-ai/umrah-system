import React from 'react';

interface EmptyStateProps {
  icon: string;
  message: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({ icon, message }) => {
  return (
    <div className="text-center py-12 text-muted">
      <div className="text-[44px] mb-3">{icon}</div>
      <div className="text-sm">{message}</div>
    </div>
  );
};
