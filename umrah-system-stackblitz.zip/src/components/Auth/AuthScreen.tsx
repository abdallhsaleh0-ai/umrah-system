import React, { useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { Button } from '../UI/Button';
import { Input } from '../UI/Input';

export const AuthScreen: React.FC = () => {
  const { login, signup, loginAsGuest } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const authErrorMap: Record<string, string> = {
    'auth/email-already-in-use': 'البريد مستخدم بالفعل',
    'auth/invalid-email': 'صيغة البريد غير صحيحة',
    'auth/weak-password': 'كلمة السر ضعيفة (6 أحرف على الأقل)',
    'auth/user-not-found': 'لا يوجد حساب بهذا البريد',
    'auth/wrong-password': 'كلمة السر غير صحيحة',
    'auth/invalid-credential': 'بيانات الدخول غير صحيحة',
    'auth/too-many-requests': 'محاولات كثيرة، حاول لاحقاً',
    'auth/network-request-failed': 'تعذر الاتصال بالشبكة',
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('يرجى إدخال البريد وكلمة السر');
      return;
    }
    if (password.length < 6) {
      setError('كلمة السر يجب أن تكون 6 أحرف على الأقل');
      return;
    }

    setLoading(true);
    try {
      if (mode === 'login') {
        await login(email, password);
      } else {
        await signup(email, password);
      }
    } catch (err: any) {
      setError(authErrorMap[err.code] || `خطأ: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleGuest = async () => {
    setLoading(true);
    try {
      await loginAsGuest();
    } catch (err: any) {
      setError(`تعذر الدخول كزائر: ${err.message || err.code}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-navy flex items-center justify-center z-[999] p-4">
      <div className="bg-navy-2 border border-white/10 rounded-[18px] p-8 w-full max-w-[380px] text-center">
        <div className="text-[46px] mb-2">🕋</div>
        <div className="text-gold font-bold text-lg mb-1">نظام إدارة رحلات العمرة</div>
        <div className="text-muted text-xs mb-5">نظام إدارة رحلات العمرة</div>

        <div className="flex gap-1.5 mb-4 bg-white/5 rounded-xl p-1">
          <button
            onClick={() => setMode('login')}
            className={`flex-1 text-center py-2 rounded-lg text-xs font-semibold transition-colors ${
              mode === 'login' ? 'bg-gold text-navy' : 'text-muted'
            }`}
          >
            تسجيل الدخول
          </button>
          <button
            onClick={() => setMode('signup')}
            className={`flex-1 text-center py-2 rounded-lg text-xs font-semibold transition-colors ${
              mode === 'signup' ? 'bg-gold text-navy' : 'text-muted'
            }`}
          >
            حساب جديد
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-right">
          <Input
            label="البريد الإلكتروني"
            type="email"
            placeholder="example@mail.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Input
            label="كلمة السر"
            type="password"
            placeholder="6 أحرف على الأقل"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <Button type="submit" variant="gold" className="w-full py-2.5" disabled={loading}>
            {mode === 'login' ? '🔓 تسجيل الدخول' : '✨ إنشاء حساب'}
          </Button>
        </form>

        <button
          onClick={handleGuest}
          disabled={loading}
          className="w-full mt-3 bg-transparent border border-dashed border-white/10 text-muted rounded-lg py-2 text-xs cursor-pointer hover:border-white/20 transition-colors"
        >
          👁️ دخول كزائر (عرض فقط)
        </button>

        {error && <p className="text-rose text-xs mt-2.5">{error}</p>}
      </div>
    </div>
  );
};
