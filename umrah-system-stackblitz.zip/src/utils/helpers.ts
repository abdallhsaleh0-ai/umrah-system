import { Pilgrim, Flight } from '../types';

export const uid = (): string => Math.random().toString(36).slice(2, 9);

export const today = (): string => new Date().toISOString().slice(0, 10);

export const fmt = (n: number): string => (n || 0).toLocaleString('ar-EG');

export const daysLeft = (date: string): number => {
  const diff = new Date(date).getTime() - Date.now();
  return diff > 0 ? Math.ceil(diff / 86400000) : 0;
};

export const esc = (s: string | undefined | null): string => {
  if (!s) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
};

export const getHotelsList = (pilgrims: Pilgrim[]): string[] => {
  const used = pilgrims
    .filter(p => !p.deleted)
    .map(p => p.hotel)
    .filter(Boolean) as string[];
  return Array.from(new Set([...HOTELS_DEFAULT, ...used]));
};

import { HOTELS_DEFAULT } from '../constants';

export const levenshtein = (a: string, b: string): number => {
  a = a || ''; b = b || '';
  const m = a.length, n = b.length;
  const dp: number[][] = [];
  for (let i = 0; i <= m; i++) {
    dp.push(new Array(n + 1).fill(0));
    dp[i][0] = i;
  }
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[m][n];
};

export const fuzzyFindPilgrim = (q: string, pilgrims: Pilgrim[]): Pilgrim | null => {
  const list = pilgrims.filter(p => !p.deleted);
  let best: Pilgrim | null = null;
  let bestDist = Infinity;
  list.forEach(p => {
    const d = levenshtein(q, p.name);
    if (d < bestDist) { bestDist = d; best = p; }
  });
  return bestDist <= 3 ? best : null;
};

export const roleLabel = (r: string): string => {
  const map: Record<string, string> = {
    admin: 'مدير',
    guest: 'زائر',
    supervisor: 'مشرف رحلة',
    user: 'مستخدم'
  };
  return map[r] || r;
};

export const roleClass = (r: string): string => {
  const map: Record<string, string> = {
    admin: 'role-admin',
    guest: 'role-guest',
    supervisor: 'role-supervisor',
    user: 'role-user'
  };
  return map[r] || 'role-user';
};

export const actionLabel = (a: string): string => {
  const map: Record<string, string> = {
    create: '➕ إضافة',
    update: '✏️ تعديل',
    delete: '🗑️ حذف (أرشيف)',
    restore: '♻️ استرجاع',
    permanent_delete: '❌ حذف نهائي',
    import: '📥 استيراد'
  };
  return map[a] || a;
};
