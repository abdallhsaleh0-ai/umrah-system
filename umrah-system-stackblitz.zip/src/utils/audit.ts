import { AuditLog } from '../types';

export const createAuditLog = (
  action: AuditLog['action'],
  entityType: string,
  entityName: string,
  userEmail: string,
  details?: string
): AuditLog => ({
  id: Math.random().toString(36).slice(2, 9),
  action,
  entityType,
  entityName,
  user: userEmail || 'غير معروف',
  time: new Date().toISOString(),
  details: details || ''
});

export const addAuditLog = (
  logs: AuditLog[],
  log: AuditLog
): AuditLog[] => {
  const newLogs = [log, ...logs];
  return newLogs.slice(0, 500);
};
