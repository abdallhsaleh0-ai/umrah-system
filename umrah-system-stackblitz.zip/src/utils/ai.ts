import { Pilgrim, Flight, Client } from '../types';
import { getHotelsList, fuzzyFindPilgrim, daysLeft } from './helpers';
import { HOTELS_DEFAULT } from '../constants';

export const localSmartAI = (
  q: string,
  pilgrims: Pilgrim[],
  flights: Flight[],
  clients: Client[],
  userRole?: string
): string => {
  const p = pilgrims.filter(x => !x.deleted && x.status !== 'ملغى' && x.status !== 'ملغي');
  const f = flights.filter(x => !x.deleted);
  const c = clients.filter(x => !x.deleted);
  const has = (...w: string[]) => w.some(x => q.includes(x));

  if (has('كام معتمر', 'عدد المعتمرين', 'إجمالي المعتمرين', 'مجموع المعتمرين')) {
    const male = p.filter(x => x.gender === 'ذكر').length;
    const female = p.filter(x => x.gender === 'أنثى').length;
    const ch = p.filter(x => x.gender === 'طفل').length;
    const inf = p.filter(x => x.gender === 'رضيع').length;
    return `📊 إجمالي المعتمرين: ${p.length} معتمر

👨 ذكور: ${male}
👩 إناث: ${female}
🧒 أطفال: ${ch}
👶 رضع: ${inf}`;
  }

  if (has('ذكر', 'ذكور', 'إناث', 'أنثى')) {
    const m = p.filter(x => x.gender === 'ذكر').length;
    const fe = p.filter(x => x.gender === 'أنثى').length;
    return `👨 الذكور: ${m}
👩 الإناث: ${fe}
الإجمالي: ${p.length}`;
  }

  if (has('أطفال', 'طفل', 'رضع', 'رضيع')) {
    const ch = p.filter(x => x.gender === 'طفل');
    const inf = p.filter(x => x.gender === 'رضيع');
    return `🧒 الأطفال (${ch.length}):
${ch.length ? ch.map(x => '• ' + x.name).join('\n') : 'لا يوجد'}

👶 الرضع (${inf.length}):
${inf.length ? inf.map(x => '• ' + x.name).join('\n') : 'لا يوجد'}`;
  }

  if (has('فندق', 'فنادق')) {
    const hotels = getHotelsList(pilgrims);
    const matchedHotel = hotels.find(h => q.includes(h));
    if (matchedHotel) {
      const list = p.filter(x => x.hotel === matchedHotel);
      return `🏨 معتمرو فندق "${matchedHotel}" (${list.length}):

${list.length ? list.map(x => '• ' + x.name).join('\n') : 'لا يوجد'}`;
    }
    const hotelCounts: Record<string, number> = {};
    p.forEach(x => { if (x.hotel) hotelCounts[x.hotel] = (hotelCounts[x.hotel] || 0) + 1; });
    const keys = Object.keys(hotelCounts);
    if (!keys.length) return 'لا توجد بيانات فنادق بعد.';
    return `🏨 توزيع الفنادق:

${keys.map(h => '• ' + h + ' — ' + hotelCounts[h] + ' معتمر').join('\n')}`;
  }

  if (has('ناقص', 'نواقص', 'مستندات', 'ناقصين', 'غير مكتمل')) {
    const ms = p.filter(x => x.status === 'ناقص مستندات');
    if (!ms.length) return '✅ جميع المعتمرين مكتملو الأوراق!';
    return `⚠️ الناقصون مستنداتهم (${ms.length}):

${ms.map(x => '• ' + x.name + (x.missing ? ' — ' + x.missing : '')).join('\n')}`;
  }

  if (has('معلق', 'معلقين')) {
    const pe = p.filter(x => x.status === 'معلق');
    return pe.length ? `🔴 المعلقون (${pe.length}):
${pe.map(x => '• ' + x.name).join('\n')}` : '✅ لا يوجد معلقون.';
  }

  if (has('ملخص', 'ملخّص')) {
    if (!f.length) return 'لا توجد رحلات.';
    const fl = f.map(fl => {
      const cnt = p.filter(x => x.flightId === fl.id).length;
      const cl = c.filter(x => x.flightId === fl.id).length;
      const d = daysLeft(fl.date);
      return `✈️ ${fl.name}
   📅 ${fl.date}${d > 0 ? ' (' + d + ' يوم)' : ' (انتهت)'}
   👥 ${cnt} معتمر · 👤 ${cl} عميل`;
    }).join('\n\n');
    return `📋 الرحلات (${f.length}):

${fl}`;
  }

  if (has('رحلة', 'رحلات', 'كام رحلة')) {
    if (!f.length) return 'لا توجد رحلات.';
    return `✈️ عدد الرحلات: ${f.length}

${f.map((fl, i) => (i + 1) + '. ' + fl.name + ' — ' + fl.date + ' — ' + p.filter(x => x.flightId === fl.id).length + ' معتمر').join('\n')}`;
  }

  if (has('عميل', 'عملاء', 'كام عميل')) {
    if (!c.length) return 'لا يوجد عملاء.';
    return `👤 العملاء (${c.length}):

${c.map(cl => '• ' + cl.name + ' (' + cl.code + ') — ' + p.filter(x => x.clientCode === cl.code).length + ' معتمر').join('\n')}`;
  }

  if (has('جواز', 'جوازات', 'منتهي', 'منتهية')) {
    const exp = p.filter(x => x.expiry && new Date(x.expiry) < new Date());
    const soon = p.filter(x => x.expiry && new Date(x.expiry) >= new Date() && new Date(x.expiry).getTime() - Date.now() < 180 * 86400000);
    return `🛂 تقرير الجوازات:

❌ منتهية: ${exp.length}
${exp.map(x => '• ' + x.name + ' (' + x.expiry + ')').join('\n')}

⚠️ تنتهي خلال 6 أشهر: ${soon.length}
${soon.map(x => '• ' + x.name + ' (' + x.expiry + ')').join('\n')}

✅ سارية: ${p.length - exp.length - soon.length}`;
  }

  if (has('الجنسية', 'الجنسيات', 'جنسية')) {
    const nats: Record<string, number> = {};
    p.forEach(x => { if (x.nationality) nats[x.nationality] = (nats[x.nationality] || 0) + 1; });
    const keys = Object.keys(nats);
    if (!keys.length) return 'لا توجد بيانات جنسيات مسجلة بعد.';
    return `🌍 توزيع الجنسيات:

${keys.map(n => '• ' + n + ' — ' + nats[n] + ' معتمر').join('\n')}`;
  }

  if (has('الأرشيف', 'المحذوف', 'المحذوفات', 'الارشيف')) {
    const trashCount = {
      flights: flights.filter(x => x.deleted).length,
      clients: clients.filter(x => x.deleted).length,
      pilgrims: pilgrims.filter(x => x.deleted).length,
    };
    const total = Object.values(trashCount).reduce((a, b) => a + b, 0);
    if (!total) return '🗑️ الأرشيف فارغ — لا يوجد عناصر محذوفة.';
    return `🗑️ الأرشيف (${total} عنصر):

✈️ رحلات: ${trashCount.flights}
👤 عملاء: ${trashCount.clients}
🗂️ معتمرين: ${trashCount.pilgrims}`;
  }

  if (has('تذاكر', 'تذكرة')) {
    if (!f.length) return 'لا توجد رحلات.';
    return `🎫 عدد التذاكر لكل رحلة:

${f.map(fl => '• ' + fl.name + ' — ' + p.filter(x => x.flightId === fl.id).length + ' تذكرة').join('\n')}`;
  }

  if (has('اليوم', 'إضافة اليوم', 'معتمرين اليوم')) {
    const t = new Date().toISOString().slice(0, 10);
    const todays = p.filter(x => x.addedAt === t);
    return todays.length ? `📅 المعتمرون المُضافون اليوم (${todays.length}):

${todays.map(x => '• ' + x.name).join('\n')}` : 'لا يوجد معتمرون مُضافون اليوم.';
  }

  if (has('نسخة احتياطية', 'باكأب', 'backup')) {
    return '💾 يمكنك عمل نسخة احتياطية كاملة بالضغط على زر "📦 نسخ احتياطي" أعلى الصفحة.';
  }

  if (has('مستخدم', 'مستخدمين', 'المستخدمين')) {
    return userRole === 'admin' ? '👥 لإدارة المستخدمين افتح صفحة "المستخدمين" من القائمة.' : '🔒 صفحة المستخدمين متاحة للمدير فقط.';
  }

  if (has('دوري', 'حالتي', 'صلاحياتي', 'دوري ايه')) {
    return userRole ? `👤 أنت مسجل بصفة: ${userRole}` : 'لم يتم تسجيل الدخول.';
  }

  if (!p.length && !f.length)
    return 'لا توجد بيانات بعد 📭

ابدأ بـ:
1️⃣ إضافة رحلة
2️⃣ إضافة عملاء
3️⃣ إضافة معتمرين

كل البيانات تُحفظ تلقائياً ☁️';

  const fuzzy = fuzzyFindPilgrim(q.trim(), pilgrims);
  if (fuzzy) {
    const fl = flights.find(x => x.id === fuzzy.flightId);
    const cl = clients.find(x => x.code === fuzzy.clientCode);
    return `🔎 أقرب نتيجة:

👤 ${fuzzy.name}
🛂 جواز: ${fuzzy.passport}
النوع: ${fuzzy.gender} | 🏨 ${fuzzy.hotel || 'غير محدد'}
📋 الحالة: ${fuzzy.status}
✈️ الرحلة: ${fl ? fl.name : '-'}
👤 العميل: ${cl ? cl.name : (fuzzy.clientCode || '-')}`;
  }

  const male = p.filter(x => x.gender === 'ذكر').length;
  const female = p.filter(x => x.gender === 'أنثى').length;
  const children = p.filter(x => x.gender === 'طفل').length;
  const infants = p.filter(x => x.gender === 'رضيع').length;
  const incomplete = p.filter(x => x.status === 'ناقص مستندات').length;

  return `📊 **ملخص النظام:**

` +
    `👥 إجمالي المعتمرين: **${p.length}**
` +
    `👨 ذكور: ${male} | 👩 إناث: ${female} | 🧒 أطفال: ${children} | 👶 رضع: ${infants}
` +
    `✈️ عدد الرحلات: **${f.length}**
` +
    `👤 عدد العملاء: **${c.length}**
` +
    `📋 ناقصو مستندات: **${incomplete}**

` +
    `💡 **اسألني عن:** معتمر معين، إحصائيات الرحلات، الفنادق، الجنسيات، الجوازات`;
};

export const buildAIContext = (
  flights: Flight[],
  clients: Client[],
  pilgrims: Pilgrim[]
): string => {
  const activePilgrims = pilgrims.filter(p => !p.deleted && p.status !== 'ملغى' && p.status !== 'ملغي');
  const activeFlights = flights.filter(f => !f.deleted);
  const activeClients = clients.filter(c => !c.deleted);

  const flightsText = activeFlights.map(f => {
    const cnt = activePilgrims.filter(p => p.flightId === f.id).length;
    const d = daysLeft(f.date);
    return `- ${f.name} | التاريخ: ${f.date} | المعتمرين: ${cnt} | ${d > 0 ? d + ' يوم متبقي' : 'انتهت'}`;
  }).join('\n');

  const clientsText = activeClients.map(c => {
    const cPilgrims = activePilgrims.filter(p => p.clientCode === c.code && p.flightId === c.flightId);
    const fl = activeFlights.find(f => f.id === c.flightId);
    return `- ${c.name} (كود:${c.code}) | الرحلة: ${fl ? fl.name : '-'} | عدد المعتمرين: ${cPilgrims.length}`;
  }).join('\n');

  const pilgrimsText = activePilgrims.slice(0, 20).map(p => {
    const fl = activeFlights.find(f => f.id === p.flightId);
    const cl = activeClients.find(c => c.code === p.clientCode);
    return `- ${p.name} | جواز:${p.passport} | ${p.gender} | جنسية:${p.nationality || '-'} | فندق:${p.hotel || '-'} | حالة:${p.status} | الرحلة:${fl ? fl.name : '-'} | العميل:${cl ? cl.name : (p.clientCode || '-')}`;
  }).join('\n');

  const incomplete = activePilgrims.filter(p => p.status === 'ناقص مستندات').length;
  const expSoon = activePilgrims.filter(p => p.expiry && new Date(p.expiry).getTime() - Date.now() < 180 * 86400000).length;

  return `=== ملخص النظام ===
عدد الرحلات: ${activeFlights.length} | عدد العملاء: ${activeClients.length} | عدد المعتمرين: ${activePilgrims.length}
معتمرون ناقصو مستندات: ${incomplete} | جوازات قريبة الانتهاء: ${expSoon}

=== الرحلات ===
${flightsText || 'لا توجد رحلات'}

=== العملاء ===
${clientsText || 'لا يوجد عملاء'}

=== المعتمرين (عينة) ===
${pilgrimsText || 'لا يوجد معتمرين'}`;
};
