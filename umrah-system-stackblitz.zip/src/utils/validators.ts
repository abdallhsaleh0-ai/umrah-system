import { Pilgrim, Client } from '../types';

export interface ValidationError {
  field: string;
  message: string;
}

export const validatePilgrim = (
  name: string,
  passport: string,
  birth: string,
  pilgrims: Pilgrim[],
  editId?: string | null
): string[] => {
  const errs: string[] = [];
  if (name.length < 2) errs.push('الاسم يجب أن يكون حرفين على الأقل');
  if (passport.length < 5) errs.push('رقم الجواز يجب أن يكون 5 خانات على الأقل');
  if (birth) {
    const b = new Date(birth);
    if (b > new Date()) errs.push('تاريخ الميلاد لا يمكن أن يكون في المستقبل');
  }
  if (name.length >= 2) {
    const dup = pilgrims.find(p => !p.deleted && p.name === name && p.id !== editId);
    if (dup) errs.push(`اسم المعتمر "${name}" مستخدم بالفعل!`);
  }
  if (passport.length >= 5) {
    const dup = pilgrims.find(p => !p.deleted && p.passport === passport && p.id !== editId);
    if (dup) errs.push(`رقم الجواز مستخدم بالفعل للمعتمر: ${dup.name}`);
  }
  return errs;
};

export const validateClient = (
  name: string,
  flightId: string | null,
  code: string,
  clients: Client[],
  editId?: string | null
): string[] => {
  const errs: string[] = [];
  if (name.length < 2) errs.push('اسم العميل يجب أن يكون حرفين على الأقل');
  if (code) {
    const dup = clients.find(c => !c.deleted && c.code === code && c.flightId === flightId && c.id !== editId);
    if (dup) errs.push('هذا العميل مُضاف بالفعل لهذه الرحلة');
  }
  return errs;
};
