import { useState, useEffect, useCallback } from 'react';
import { onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signInAnonymously, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../firebase/config';
import { User, UserRole } from '../types';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        if (firebaseUser.isAnonymous) {
          setUser({
            uid: firebaseUser.uid,
            email: 'زائر (عرض فقط)',
            role: 'guest'
          });
        } else {
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
          let role: UserRole = 'user';

          if (userDoc.exists()) {
            role = (userDoc.data().role as UserRole) || 'user';
          } else {
            const allUsers = await getDoc(doc(db, 'users', '_count'));
            if (!allUsers.exists()) role = 'admin';

            await setDoc(doc(db, 'users', firebaseUser.uid), {
              email: firebaseUser.email,
              role,
              createdAt: serverTimestamp()
            });
          }

          setUser({
            uid: firebaseUser.uid,
            email: firebaseUser.email || '',
            role
          });
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = useCallback((email: string, password: string) => 
    signInWithEmailAndPassword(auth, email, password), []);

  const signup = useCallback((email: string, password: string) => 
    createUserWithEmailAndPassword(auth, email, password), []);

  const loginAsGuest = useCallback(() => signInAnonymously(auth), []);

  const logout = useCallback(() => signOut(auth), []);

  const canEdit = useCallback(() => user?.role === 'admin' || user?.role === 'user', [user]);
  const canPrint = useCallback(() => user?.role !== 'guest', [user]);
  const isAdmin = useCallback(() => user?.role === 'admin', [user]);

  return { user, loading, login, signup, loginAsGuest, logout, canEdit, canPrint, isAdmin };
}
