import { initializeApp } from 'firebase/app';
import { getFirestore, enableIndexedDbPersistence } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyCcwFruiOOx2AsozvE5tzpJHbqqcyUBepU",
  authDomain: "umrah-system-1c258.firebaseapp.com",
  projectId: "umrah-system-1c258",
  storageBucket: "umrah-system-1c258.firebasestorage.app",
  messagingSenderId: "257236701239",
  appId: "1:257236701239:web:b530859b9ee393b18a6fb2"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);

// Enable offline persistence
enableIndexedDbPersistence(db).catch((err) => {
  if (err.code === 'failed-precondition') {
    console.warn('Multiple tabs open, persistence can only be enabled in one tab at a time.');
  } else if (err.code === 'unimplemented') {
    console.warn('Browser does not support offline persistence.');
  }
});
