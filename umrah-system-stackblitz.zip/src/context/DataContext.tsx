import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { AppData, Flight, Client, Pilgrim, AuditLog } from '../types';
import { createAuditLog, addAuditLog } from '../utils/audit';

interface DataStore extends AppData {
  loading: boolean;
  fbConnected: boolean;
  currentUser: string;
  setData: (data: Partial<AppData>) => void;
  setFbConnected: (connected: boolean) => void;
  setCurrentUser: (user: string) => void;
  addFlight: (flight: Flight, userEmail: string) => void;
  updateFlight: (id: string, flight: Partial<Flight>, userEmail: string) => void;
  deleteFlight: (id: string, userEmail: string) => void;
  restoreFlight: (id: string, userEmail: string) => void;
  addClient: (client: Client, userEmail: string) => void;
  updateClient: (id: string, client: Partial<Client>, userEmail: string) => void;
  deleteClient: (id: string, userEmail: string) => void;
  restoreClient: (id: string, userEmail: string) => void;
  addPilgrim: (pilgrim: Pilgrim, userEmail: string) => void;
  updatePilgrim: (id: string, pilgrim: Partial<Pilgrim>, userEmail: string) => void;
  deletePilgrim: (id: string, userEmail: string) => void;
  restorePilgrim: (id: string, userEmail: string) => void;
  permanentDelete: (type: 'flights' | 'clients' | 'pilgrims', id: string, userEmail: string) => void;
  importData: (data: AppData, userEmail: string) => void;
  syncFromFirebase: (data: AppData) => void;
}

const normalizeData = (d: Partial<AppData>): AppData => ({
  flights: Array.isArray(d.flights) ? d.flights : [],
  clients: Array.isArray(d.clients) ? d.clients : [],
  pilgrims: Array.isArray(d.pilgrims) ? d.pilgrims : [],
  auditLog: Array.isArray(d.auditLog) ? d.auditLog : [],
});

export const useDataStore = create<DataStore>()(
  persist(
    (set, get) => ({
      flights: [],
      clients: [],
      pilgrims: [],
      auditLog: [],
      loading: false,
      fbConnected: false,
      currentUser: '',

      setData: (data) => set((state) => ({ ...state, ...normalizeData(data) })),

      setFbConnected: (connected) => set({ fbConnected: connected }),

      setCurrentUser: (user) => set({ currentUser: user }),

      addFlight: (flight, userEmail) => set((state) => {
        const log = createAuditLog('create', 'flights', flight.name, userEmail);
        return {
          flights: [...state.flights, flight],
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      updateFlight: (id, flight, userEmail) => set((state) => {
        const existing = state.flights.find(f => f.id === id);
        const log = createAuditLog('update', 'flights', existing?.name || id, userEmail);
        return {
          flights: state.flights.map(f => f.id === id ? { ...f, ...flight } : f),
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      deleteFlight: (id, userEmail) => set((state) => {
        const existing = state.flights.find(f => f.id === id);
        const log = createAuditLog('delete', 'flights', existing?.name || id, userEmail);
        return {
          flights: state.flights.map(f => f.id === id ? { ...f, deleted: true, deletedAt: new Date().toISOString(), deletedBy: userEmail } : f),
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      restoreFlight: (id, userEmail) => set((state) => {
        const existing = state.flights.find(f => f.id === id);
        const log = createAuditLog('restore', 'flights', existing?.name || id, userEmail);
        const { deleted, deletedAt, deletedBy, ...rest } = existing || {};
        return {
          flights: state.flights.map(f => f.id === id ? rest as Flight : f),
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      addClient: (client, userEmail) => set((state) => {
        const log = createAuditLog('create', 'clients', client.name, userEmail);
        return {
          clients: [...state.clients, client],
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      updateClient: (id, client, userEmail) => set((state) => {
        const existing = state.clients.find(c => c.id === id);
        const log = createAuditLog('update', 'clients', existing?.name || id, userEmail);
        return {
          clients: state.clients.map(c => c.id === id ? { ...c, ...client } : c),
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      deleteClient: (id, userEmail) => set((state) => {
        const existing = state.clients.find(c => c.id === id);
        const log = createAuditLog('delete', 'clients', existing?.name || id, userEmail);
        return {
          clients: state.clients.map(c => c.id === id ? { ...c, deleted: true, deletedAt: new Date().toISOString(), deletedBy: userEmail } : c),
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      restoreClient: (id, userEmail) => set((state) => {
        const existing = state.clients.find(c => c.id === id);
        const log = createAuditLog('restore', 'clients', existing?.name || id, userEmail);
        const { deleted, deletedAt, deletedBy, ...rest } = existing || {};
        return {
          clients: state.clients.map(c => c.id === id ? rest as Client : c),
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      addPilgrim: (pilgrim, userEmail) => set((state) => {
        const log = createAuditLog('create', 'pilgrims', pilgrim.name, userEmail);
        return {
          pilgrims: [...state.pilgrims, pilgrim],
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      updatePilgrim: (id, pilgrim, userEmail) => set((state) => {
        const existing = state.pilgrims.find(p => p.id === id);
        const log = createAuditLog('update', 'pilgrims', existing?.name || id, userEmail);
        return {
          pilgrims: state.pilgrims.map(p => p.id === id ? { ...p, ...pilgrim } : p),
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      deletePilgrim: (id, userEmail) => set((state) => {
        const existing = state.pilgrims.find(p => p.id === id);
        const log = createAuditLog('delete', 'pilgrims', existing?.name || id, userEmail);
        return {
          pilgrims: state.pilgrims.map(p => p.id === id ? { ...p, deleted: true, deletedAt: new Date().toISOString(), deletedBy: userEmail } : p),
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      restorePilgrim: (id, userEmail) => set((state) => {
        const existing = state.pilgrims.find(p => p.id === id);
        const log = createAuditLog('restore', 'pilgrims', existing?.name || id, userEmail);
        const { deleted, deletedAt, deletedBy, ...rest } = existing || {};
        return {
          pilgrims: state.pilgrims.map(p => p.id === id ? rest as Pilgrim : p),
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      permanentDelete: (type, id, userEmail) => set((state) => {
        const existing = state[type].find((x: any) => x.id === id);
        const log = createAuditLog('permanent_delete', type, existing?.name || existing?.code || id, userEmail);
        return {
          [type]: state[type].filter((x: any) => x.id !== id),
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      importData: (data, userEmail) => set((state) => {
        const log = createAuditLog('import', 'system', 'استيراد نسخة احتياطية كاملة', userEmail);
        return {
          ...normalizeData(data),
          auditLog: addAuditLog(state.auditLog, log)
        };
      }),

      syncFromFirebase: (data) => set((state) => ({
        ...state,
        ...normalizeData(data),
        fbConnected: true
      })),
    }),
    {
      name: 'umrah-data-storage',
    }
  )
);
