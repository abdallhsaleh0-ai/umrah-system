import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';
import { useDataStore } from './context/DataContext';
import { db } from './firebase/config';
import { doc, onSnapshot } from 'firebase/firestore';
import { Sidebar, Header, BottomNav } from './components/Layout';
import { AuthScreen } from './components/Auth';
import { LoadingScreen } from './components/UI';
import { Dashboard, Flights, Clients, Pilgrims, Tickets, ClientReports, Trash, AuditLog, Users, AIAssistant } from './pages';

export const App: React.FC = () => {
  const { user, loading: authLoading } = useAuth();
  const { setFbConnected, setCurrentUser, syncFromFirebase } = useDataStore();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [connStatus, setConnStatus] = useState<{ status: 'ok' | 'err' | 'loading'; message: string }>({ status: 'loading', message: '⏳ جاري الاتصال...' });

  // Firebase sync
  useEffect(() => {
    if (!user) return;

    setCurrentUser(user.email);
    const unsub = onSnapshot(doc(db, 'umrah_system', 'main_data'), 
      (snap) => {
        if (snap.exists()) {
          syncFromFirebase(snap.data() as any);
          setConnStatus({ status: 'ok', message: '☁️ متصل بـ Firebase' });
        }
      },
      (err) => {
        console.error('Firebase error:', err);
        setConnStatus({ status: 'err', message: '❌ Firebase غير متاح — يعمل محلياً' });
      }
    );

    return () => unsub();
  }, [user]);

  const handleSync = async () => {
    setConnStatus({ status: 'loading', message: '⏳ جاري المزامنة...' });
    try {
      const { getDoc } = await import('firebase/firestore');
      const snap = await getDoc(doc(db, 'umrah_system', 'main_data'));
      if (snap.exists()) {
        syncFromFirebase(snap.data() as any);
        setConnStatus({ status: 'ok', message: '☁️ تمت المزامنة ✅' });
      }
    } catch (e) {
      setConnStatus({ status: 'err', message: '❌ فشل التزامن' });
    }
  };

  const handleBackup = () => {
    const data = useDataStore.getState();
    const json = JSON.stringify({ 
      flights: data.flights, 
      clients: data.clients, 
      pilgrims: data.pilgrims, 
      auditLog: data.auditLog 
    }, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `نسخة_احتياطية_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (authLoading) return <LoadingScreen />;
  if (!user) return <AuthScreen />;

  return (
    <BrowserRouter>
      <div className="flex h-screen bg-navy text-gray-200 overflow-hidden" dir="rtl">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <Header 
            onMenuClick={() => setSidebarOpen(true)} 
            onBackupClick={handleBackup}
            onSyncClick={handleSync}
            connStatus={connStatus}
          />

          <main className="flex-1 overflow-y-auto p-4 pb-20 lg:pb-4">
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/flights" element={<Flights />} />
              <Route path="/clients" element={<Clients />} />
              <Route path="/pilgrims" element={<Pilgrims />} />
              <Route path="/tickets" element={<Tickets />} />
              <Route path="/client-reports" element={<ClientReports />} />
              <Route path="/trash" element={<Trash />} />
              <Route path="/audit" element={<AuditLog />} />
              <Route path="/users" element={<Users />} />
              <Route path="/ai" element={<AIAssistant />} />
            </Routes>
          </main>

          <BottomNav />
        </div>
      </div>
    </BrowserRouter>
  );
};
