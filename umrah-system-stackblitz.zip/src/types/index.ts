export type UserRole = 'admin' | 'user' | 'supervisor' | 'guest';

export interface User {
  uid: string;
  email: string;
  role: UserRole;
}

export interface Flight {
  id: string;
  name: string;
  date: string;
  seats: number;
  notes?: string;
  deleted?: boolean;
  deletedAt?: string;
  deletedBy?: string;
  createdAt?: string;
}

export interface Client {
  id: string;
  code: string;
  name: string;
  phone: string;
  city: string;
  flightId: string | null;
  deleted?: boolean;
  deletedAt?: string;
  deletedBy?: string;
}

export interface Pilgrim {
  id: string;
  name: string;
  passport: string;
  birth?: string;
  expiry?: string;
  gender: 'ذكر' | 'أنثى' | 'طفل' | 'رضيع';
  nationality?: string;
  hotel?: string;
  room_type?: string;
  visa_type?: string;
  military?: string;
  status: 'مكتمل' | 'ناقص مستندات' | 'معلق' | 'ملغي';
  address?: string;
  mahram?: string;
  relation?: string;
  missing?: string;
  clientCode: string;
  flightId: string;
  notes?: string;
  addedAt?: string;
  deleted?: boolean;
  deletedAt?: string;
  deletedBy?: string;
}

export interface AuditLog {
  id: string;
  action: 'create' | 'update' | 'delete' | 'restore' | 'permanent_delete' | 'import';
  entityType: string;
  entityName: string;
  user: string;
  time: string;
  details?: string;
}

export interface AppData {
  flights: Flight[];
  clients: Client[];
  pilgrims: Pilgrim[];
  auditLog: AuditLog[];
}

export interface AIMessage {
  role: 'user' | 'assistant';
  content: string;
}

export type NavItem = {
  id: string;
  icon: string;
  label: string;
  bn: boolean;
  adminOnly?: boolean;
};
