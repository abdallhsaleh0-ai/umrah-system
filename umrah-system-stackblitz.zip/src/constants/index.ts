export const BRAND_SIGNATURE = "🕋 نظام إدارة رحلات العمرة";
export const LOCAL_KEY = 'umrah_backup_v8_final';
export const ANTHROPIC_API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY || '';

export const HOTELS_DEFAULT = [
  'فندق الحرم',
  'فندق البركة',
  'فندق دار التوحيد',
  'فندق أنوار المدينة',
  'فندق المروة روتانا'
];

export const NAV_ITEMS = [
  { id: 'dashboard', icon: '📊', label: 'الرئيسية', bn: true },
  { id: 'flights', icon: '✈️', label: 'الرحلات', bn: true },
  { id: 'clients', icon: '👤', label: 'العملاء', bn: false },
  { id: 'pilgrims', icon: '🗂️', label: 'المعتمرين', bn: true },
  { id: 'tickets', icon: '🎫', label: 'تذاكر الرحلة', bn: false },
  { id: 'client-reports', icon: '📄', label: 'تقارير العملاء', bn: false },
  { id: 'trash', icon: '🗑️', label: 'الأرشيف', bn: false },
  { id: 'audit', icon: '📜', label: 'سجل التعديلات', bn: false },
  { id: 'users', icon: '👥', label: 'المستخدمين', bn: false, adminOnly: true },
  { id: 'ai', icon: '🤖', label: 'المساعد الذكي', bn: true },
];

export const GENDER_OPTIONS = ['ذكر', 'أنثى', 'طفل', 'رضيع'] as const;
export const STATUS_OPTIONS = ['مكتمل', 'ناقص مستندات', 'معلق', 'ملغي'] as const;
export const VISA_OPTIONS = ['عمرة', 'زيارة عائلية', 'زيارة شخصية', 'سياحية', 'زيارة أعمال'] as const;
export const MILITARY_OPTIONS = ['أدى الخدمة', 'معفى', 'في سن التجنيد', 'غير مطلوب', '-'] as const;
export const ROOM_OPTIONS = ['ثنائي', 'ثلاثي', 'رباعي', 'خماسي', 'بدون تحديد'] as const;
